﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingApplication
{
    public abstract class Account
    {
        public readonly long accountNumber;
        public string userName;
        public int balance = 0;
        public Account()
        {
            this.accountNumber = genRandomnum();


        }

        public abstract void OpenAccount();
        public abstract void CloseAccount();
        public abstract void EditAccount();
        public abstract void Deposit();
        public abstract void Withdrawal();
        public abstract void CheckBalance();

        long genRandomnum()
        {
            long acc_num = 0;
            Random r = new Random();
            string w = "";
            int i;
            for (i = 1; i < 13; i++)
            {
                w += r.Next(0, 9).ToString();
            }
            if (w.Length == 12)
            {
                acc_num = Convert.ToInt64(w);

            }

            return acc_num;

        }

    }
}
