﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingApplication
{
    class MainClass
    {
        public static List<SavingsAccount> savlist = new List<SavingsAccount>();
        public static List<CurrentAccount> cavlist = new List<CurrentAccount>();
        static void Main(string[] args)
        {
            string Confirm;
            do
            {
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.WriteLine("Welcome to the Banking Application");
                Console.WriteLine("1. SavingsAccount \n2. CurrentAccount");
                Console.ResetColor();
                int choice = GetInt("Enter your choice");


                switch (choice)
                {
                    case 1:
                        displayMenu();
                        SavingsAccount sav = new SavingsAccount();
                        accountOptions(sav);
                        break;

                    case 2:
                        displayMenu();
                        CurrentAccount cav = new CurrentAccount();
                        accountOptions(cav);
                        break;

                    default:
                        Console.WriteLine("Invalid Selection");
                        break;
                }
                Console.WriteLine("Enter 'E' to continue");
                Confirm = Console.ReadLine().ToUpper();
            } while (Confirm == "E");


        }

        private static int GetInt(string message)
        {
            int val = 0;
            while (true)
            {

                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                    break;
                Console.ForegroundColor = ConsoleColor.DarkMagenta;
                Console.WriteLine("Incorrect Number Please Try Again");
                Console.ResetColor();
            }
            return val;
        }

        public static void displayMenu()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("1.Create an account");
            Console.WriteLine("2.Edit Account");
            Console.WriteLine("3.Deposit");
            Console.WriteLine("4.Withdrawal");
            Console.WriteLine("5.Check Balance");
            Console.WriteLine("6.CloseAccount");
            Console.WriteLine("7.Amount Transactions");


            Console.ResetColor();

        }

        public static void accountOptions(SavingsAccount obj)
        {
            int choice = GetInt("Enter the choice");
            switch (choice)
            {
                case 1:
                    obj.OpenAccount();
                    savlist.Add(obj);
                    break;
                case 2:
                    obj.EditAccount();
                    break;
                case 3:
                    obj.Deposit();
                    break;
                case 4:
                    obj.Withdrawal();
                    break;
                case 5:
                    obj.CheckBalance();
                    break;
                case 6:
                    obj.CloseAccount();
                    break;
                case 7:
                    obj.TransferAmount();
                    break;
                default:
                    Console.WriteLine("Please choose a valid option");
                    break;
            }
        }

        public static void accountOptions(CurrentAccount obj)
        {
            int choice = GetInt("Enter the choice");
            switch (choice)
            {
                case 1:
                    obj.OpenAccount();
                    cavlist.Add(obj);
                    break;
                case 2:
                    obj.EditAccount();
                    break;
                case 3:
                    obj.Deposit();
                    break;
                case 4:
                    obj.Withdrawal();
                    break;
                case 5:
                    obj.CheckBalance();
                    break;
                case 6:
                    obj.CloseAccount();
                    break;
                case 7:
                    obj.TransferAmount();
                    break;
                default:
                    Console.WriteLine("Please choose a valid option");
                    break;
            }
        }
    }
}



