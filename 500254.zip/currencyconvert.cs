﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Currency_converter
{
    class converter
    {
        int ind_money1;

        public void dollor_convert()
        {
            double US_dollar = 65.47;
            double Dollor;
            Console.WriteLine("indian money");
            ind_money1 = Convert.ToInt32(Console.ReadLine());
            Dollor = ind_money1 / US_dollar;
            Console.WriteLine("converted US money\t{0}", Dollor);
        }
    }
       class british
        {
        int ind_money;
            public void pound_convert()
        {
            
            double pound;
            double BRIT_pound = 81.18;
            Console.WriteLine("indian money");
            ind_money = Convert.ToInt32(Console.ReadLine());
            pound = ind_money / BRIT_pound;
            Console.WriteLine($"converted BRITISH money{1}",pound);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            converter con = new converter();
            con.dollor_convert();
            british brit = new british();
            brit.pound_convert();
            Console.ReadKey();
        }
        
    }
}
