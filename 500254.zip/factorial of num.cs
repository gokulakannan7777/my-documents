﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace factorial_of_num
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the number");
            int number = Convert.ToInt32(Console.ReadLine());
            long fact = 1;
            int i = 1;
            while(i<=number)
            {
                fact = fact * i;
                i = i + 1;
            }
            Console.WriteLine("factorial of a given number{0}", fact);
            Console.ReadKey();
        }
    }
}
