﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindrome
{
    class Program
    {
        static void Main(string[] args)
        {
            string str, revs = "";
            Console.WriteLine(" Enter the string");
            str = Console.ReadLine();
            for (int i = str.Length - 1; i >= 0; i--) 
            {
                revs += str[i].ToString();
            }
            if (revs == str) // Checking whether string is palindrome or not
            {
                Console.WriteLine("String is Palindrome{0}", str);
            }
            else
            {
                Console.WriteLine("String is not Palindrome {0}", str);
            }
            Console.ReadKey();
        }
    }
}
