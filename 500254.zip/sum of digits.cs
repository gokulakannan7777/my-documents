﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sum_of_digits
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the number ");
            int num;
            num = Convert.ToInt32(Console.ReadLine());
            int i = 0;
            int sum = 0;
            while(num!=0)
            {
                i = num % 10;
                num = num / 10;
                sum = sum + i;
            }
            Console.WriteLine("sum of a digit of a number{0}", sum);
            Console.ReadKey();
        }
    }
}
