﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main()
        {
            
            Console.WriteLine("enter a number=");
            long num;
            num =Convert.ToInt64(Console.ReadLine());
            long Reverse = 0;
            while (num > 0)
            {
                long remainder = num%10;
                Reverse = (Reverse * 10) + remainder;
                num = num / 10;
            }
            Console.WriteLine("Reverse No. is {0}", Reverse);
            Console.ReadKey();
        }
    }
}
