﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{
    class Program
    {
        private static int amount=0,withdraw;
        private static string Name;
        static void Main(string[] args)
        {
            int amount = 0, deposit, withdrawl;
            int choice,  x = 0;
            Console.WriteLine("1. To deposit an amount\n");
            Console.WriteLine("2. To withdraw an amount\n");
            Console.WriteLine("3. To diplay the name and balance\n");
            Console.WriteLine("Enter your choice: ");
            choice = Convert.IntTo32(Console.ReadLine());
            switch(choice)
            {
                case 1:
                    Deposit();
                    break;
                case 2:
                    Withdrawl();
                    break;
                case 4:
                    Details();
                    break;
            }
            Console.ReadKey();
        }

        private static void Initial()
        {
            Console.WriteLine("Enter the Name:\n");
            Name = Console.ReadLine();
            Console.WriteLine("Enter the Account Number:\n");
            int accnum=Convert.IntTo32(Console.ReadLine());
            Console.WriteLine("Saving or Cuurent\n");
            string acctype = Console.ReadLine();
        }

        private static void Details()
        {
            Console.WriteLine("Name of the account hoder:");
            Console.WriteLine($"Balance of :{Name }is{amount}");
        }

        private static void Withdraw()
        {
            Console.WriteLine("\n ENTER THE AMOUNT TO WITHDRAW: ");
            withdraw = Convert.IntTo32(Console.ReadLine());
            if (withdraw % 100 != 0)
            {
                Console.WriteLine("\n PLEASE ENTER THE AMOUNT IN MULTIPLES OF 100");
            }
            else if (withdraw > (amount - 500))
            {
                Console.WriteLine("\n INSUFFICENT BALANCE");
            }
            else
            {
                amount = amount - withdraw;
                Console.WriteLine("\n\n PLEASE COLLECT CASH");
                Console.WriteLine("\n YOUR CURRENT BALANCE IS {0}", amount);
            }
        }

        private static void Deposit()
        {
            Console.WriteLine("\n ENTER THE AMOUNT TO DEPOSIT");
            int deposit = Convert.IntTo32(Console.ReadLine());
            amount = + deposit;
            Console.WriteLine("YOUR BALANCE IS {0}", amount);
        }
    }
}
