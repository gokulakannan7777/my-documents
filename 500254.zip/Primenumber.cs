﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Primenum
{
    class Program
    {
        static void Main(string[] args)
        {
           Program mpc = new Program();
            Console.WriteLine("Enter the Number:");
            int number=Convert.IntTo32(Console.ReadLine());
            bool x = mpc.isPrimeNumber(number);
            Console.WriteLine("Result:" + x);
            Console.ReadKey();
        }

        public bool isPrimeNumber(int number)
        {

            for (int i = 2; i <= number - 1; i++)
            {
                if (number % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
