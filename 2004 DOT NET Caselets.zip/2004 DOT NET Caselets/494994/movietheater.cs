﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace movietheater2
{

    abstract class theater
    {
        public string Name;
        public int LicenceNo;
        public string Cityname;
        public string Address;
        public int Maxticketprice;
        public int Minticketprice;
        public static readonly int a = 10000;
        public void AddNewtheater()
        {
            

        }
        public void Deletetheater() { }
        public void Displayalltheater() { }
        public void SearchByCity() { }
        public void SearchByTheaterName() { }
        public void SearchByLicenceNumber() { }
    }
    class NoTheaterException : Exception
    {
        public string msg = "Theater not available ";
        public string notheater()
        {
            return msg;
        }
    }
    class Regulartheater : theater
    {
        public int Maxcapacity { get; set; }
        public int Mincapacity { get; set; }
        public int Minticketprice { get; set; }
        public int Maxticketprice { get; set; }
         
        int i = 1;
        List<Regulartheater> Theaters = new List<Regulartheater>();
        
        
        public void Addtheater()
        {
            Regulartheater R = new Regulartheater();
            Console.WriteLine("Enter the Theater name");
            R.Name = Console.ReadLine();
            Console.WriteLine("Enter the City name");
            R.Cityname = Console.ReadLine();
            Console.WriteLine("Enter the Theater Address");
            R.Address = Console.ReadLine();
            Console.WriteLine("Enter the Maxticket price");
            R.Maxticketprice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Minticket price");
            R.Minticketprice = Convert.ToInt32(Console.ReadLine());
            R.LicenceNo = a + i++;
            Console.WriteLine("Enter the Max capacity of the theater");
            R.Maxcapacity = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Min capacity of the theater");
            R.Mincapacity = Convert.ToInt32(Console.ReadLine());
            Theaters.Add(R);
        }
        public void Deletetheater()
        {
            string tname; bool temp = false;
            Console.WriteLine("Enter the Theater name");
            tname = Console.ReadLine();
            try
            {
                foreach (Regulartheater x in Theaters)
                {
                    if (tname == x.Name)
                    {
                        temp = true;
                        Theaters.Remove(x);
                        return;
                    }
                }
                if (temp == false)
                {
                    throw new NoTheaterException();
                }
            }
            catch (NoTheaterException e)
            {
                Console.WriteLine(e.msg);
            }
        }
        public void Displayalltheater()
        {
            bool temp = false;
            Console.WriteLine("List of PVR theaters");
            try
            {
                foreach (Regulartheater r in Theaters)
                {
                    temp = true;
                    Console.WriteLine(r.Name);
                    Console.WriteLine(r.LicenceNo.ToString());
                    Console.WriteLine(r.Address);
                    Console.WriteLine(r.Cityname);
                }
                if (temp == false)
                {
                    throw new NoTheaterException();
                }
            }
            catch (NoTheaterException e)
            {
                Console.WriteLine(e.msg);
            }

        }
        public void SearchByCity()
        {
            string cname; bool temp = false;
            Console.WriteLine("Enter the City name");
            cname = Console.ReadLine();
            try
            {
                foreach (Regulartheater r in Theaters)
                {
                    if (r.Cityname == cname)
                    {
                        temp = true;
                        Console.WriteLine("Theater found");
                        Console.WriteLine(r.Name);
                        Console.WriteLine(r.LicenceNo.ToString());
                        Console.WriteLine(r.Address);
                        Console.WriteLine(r.Cityname);
                    }
                }
                if (temp == false)
                {
                    throw new NoTheaterException();
                }
            }
            catch (NoTheaterException e)
            {
                Console.WriteLine(e.msg);
            }
        }
        public void SearchByTheaterName()
        {
            string name; bool temp = false;
            Console.WriteLine("Enter the Theater name");
            name = Console.ReadLine();
            try
            {
                foreach (Regulartheater r in Theaters)
                {
                    if (r.Name == name)
                    {
                        temp = true;
                        Console.WriteLine("Theater found");
                        Console.WriteLine(r.Name);
                        Console.WriteLine(r.LicenceNo.ToString());
                        Console.WriteLine(r.Address);
                        Console.WriteLine(r.Cityname);
                    }
                }
                if (temp == false)
                {
                    throw new NoTheaterException();
                }
            }
            catch (NoTheaterException e)
            {
                Console.WriteLine(e.msg);
            }
        }
        public void SearchByLicenceNumber()
        {
            int lic; bool temp = false;
            Console.WriteLine("Enter the Theater name");
            lic = Convert.ToInt32(Console.ReadLine());
            try
            {
                foreach (Regulartheater r in Theaters)
                {
                    if (r.LicenceNo == lic)
                    {
                        temp = true;
                        Console.WriteLine("Theater found");
                        Console.WriteLine(r.Name);
                        Console.WriteLine(r.LicenceNo.ToString());
                        Console.WriteLine(r.Address);
                        Console.WriteLine(r.Cityname);
                    }
                }
                if (temp == false)
                {
                    throw new NoTheaterException();
                }
            }
            catch (NoTheaterException e)
            {
                Console.WriteLine(e.msg);
            }
        }

    }
    class PVRtheater : theater
    {
        public int Maxcapacity { get; set; }
        public int Mincapacity { get; set; }
        public int Minticketprice { get; set; }
        public int Maxticketprice { get; set; }
        public int i = 1;
        
        List<PVRtheater> Ptheater = new List<PVRtheater>();
        public void Addtheater()
        {
            PVRtheater P = new PVRtheater();
            Console.WriteLine("Enter the Theater name");
            P.Name = Console.ReadLine();
            Console.WriteLine("Enter the City name");
            P.Cityname = Console.ReadLine();
            Console.WriteLine("Enter the Theater Address");
            P.Address = Console.ReadLine();
            Console.WriteLine("Enter the Maxticket price");
            P.Maxticketprice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Minticket price");
            P.Minticketprice = Convert.ToInt32(Console.ReadLine());
            P.LicenceNo = a + i++;
            Console.WriteLine("Enter the Max capacity of the theater");
            P.Maxcapacity = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Min capacity of the theater");
            P.Mincapacity = Convert.ToInt32(Console.ReadLine());
            Ptheater.Add(P);
        }
        public void Deletetheater()
        {
            string tname; bool temp = false;
            Console.WriteLine("Enter the Theater name");
            tname = Console.ReadLine();
            try
            {
                foreach (PVRtheater x in Ptheater)
                {
                    if (tname == x.Name)
                    {
                        temp = true;
                        Ptheater.Remove(x);
                        return;
                    }
                }
                if (temp == false)
                {
                    throw new NoTheaterException();
                }
            }
            catch (NoTheaterException e)
            {
                Console.WriteLine(e.msg);
            }
        }
        public void Displayalltheater()
        {
            bool temp = false;
            Console.WriteLine("List of PVR theaters");
            try
            {
                foreach (PVRtheater r in Ptheater)
                {
                    temp = true;
                    Console.WriteLine(r.Name);
                    Console.WriteLine(r.LicenceNo.ToString());
                    Console.WriteLine(r.Address);
                    Console.WriteLine(r.Cityname);
                }
                if (temp == false)
                {
                    throw new NoTheaterException();
                }
            }
            catch (NoTheaterException e)
            {
                Console.WriteLine(e.msg);
            }

        }
        public void SearchByCity()
        {
            string cname; bool temp = false;
            Console.WriteLine("Enter the City name");
            cname = Console.ReadLine();
            try
            {
                foreach (PVRtheater r in Ptheater)
                {
                    if (r.Cityname == cname)
                    {
                        temp = true;
                        Console.WriteLine("Theater found");
                        Console.WriteLine(r.Name);
                        Console.WriteLine(r.LicenceNo.ToString());
                        Console.WriteLine(r.Address);
                        Console.WriteLine(r.Cityname);
                    }
                }
                if (temp == false)
                {
                    throw new NoTheaterException();
                }
            }
            catch (NoTheaterException e)
            {
                Console.WriteLine(e.msg);
            }
        }
        public void SearchByTheaterName()
        {
            string name; bool temp = false;
            Console.WriteLine("Enter the Theater name");
            name = Console.ReadLine();
            try
            {
                foreach (PVRtheater r in Ptheater)
                {
                    if (r.Name == name)
                    {
                        temp = true;
                        Console.WriteLine("Theater found");
                        Console.WriteLine(r.Name);
                        Console.WriteLine(r.LicenceNo.ToString());
                        Console.WriteLine(r.Address);
                        Console.WriteLine(r.Cityname);
                    }
                }
                if (temp == false)
                {
                    throw new NoTheaterException();
                }
            }
            catch (NoTheaterException e)
            {
                Console.WriteLine(e.msg);
            }
        }
        public void SearchByLicenceNumber()
        {
            int lic; bool temp = false;
            Console.WriteLine("Enter the Theater name");
            lic = Convert.ToInt32(Console.ReadLine());
            try
            {
                foreach (PVRtheater r in Ptheater)
                {
                    if (r.LicenceNo == lic)
                    {
                        temp = true;
                        Console.WriteLine("Theater found");
                        Console.WriteLine(r.Name);
                        Console.WriteLine(r.LicenceNo.ToString());
                        Console.WriteLine(r.Address);
                        Console.WriteLine(r.Cityname);
                    }
                }
                if (temp == false)
                {
                    throw new NoTheaterException();
                }
            }
            catch (NoTheaterException e)
            {
                Console.WriteLine(e.msg);
            }
        }

    }



    class Program
    {
        static void Main(string[] args)
        {
            int ch, i;
            Regulartheater R1 = new Regulartheater();
            PVRtheater P1 = new PVRtheater();
            
           a: Console.WriteLine(" 1:AddNewTheater\n 2:DeleteTheater\n 3:DisplayAllTheaters\n 4:SearchByCity\n 5:SearchByTheaterName\n 6:SearchByLicenceNo\n 7:exit");
                Console.WriteLine("Enter your choice");
                ch = Convert.ToInt32(Console.ReadLine());
                switch(ch)
                {
                    case 1: Console.WriteLine(" 1:RegularTheater\n 2:PVRTheater");
                        Console.WriteLine("Enter the type of theater to be added");
                        i = Convert.ToInt32(Console.ReadLine());
                        if (i == 1)
                        {
                            R1.Addtheater();

                        }
                        else if (i == 2)
                        {
                            P1.Addtheater();
                        }
                        goto a;
                        
                    case 2: Console.WriteLine("1:RegularTheater\n 2:PVRTheater");
                        Console.WriteLine("Enter the type of theater to be deleted");
                        i = Convert.ToInt32(Console.ReadLine());
                        if (i == 1)
                        {
                            R1.Deletetheater();
                        }
                        else if (i == 2)
                        {
                            P1.Deletetheater();
                        }
                        goto a;
                        
                    case 3: Console.WriteLine("1:RegularTheater\n 2:PVRTheater\n 3:Both");
                        Console.WriteLine("Enter the type of theater to be displayed");
                        i = Convert.ToInt32(Console.ReadLine());
                        if (i == 1)
                        {
                            R1.Displayalltheater();
                        }
                        else if (i == 2)
                        {
                            P1.Displayalltheater();
                        }
                        else if(i==3)
                        {
                            R1.Displayalltheater();
                            P1.Displayalltheater();
                        }
                         goto a;
                    case 4:
                         Console.WriteLine("1:RegularTheater\n 2:PVRTheater\n 3:Both\n");
                         Console.WriteLine("Enter the city name");
                         i = Convert.ToInt32(Console.ReadLine());
                         if (i == 1)
                         {
                             R1.SearchByCity();
                         }
                         else if (i == 2)
                         {
                             P1.SearchByCity();
                         }
                         else if(i==3)
                         {
                             R1.SearchByCity();
                             P1.SearchByCity();
                         }
                         goto a;
                    case 5:
                         Console.WriteLine("1:RegularTheater\n 2:PVRTheater");
                         Console.WriteLine("Enter the theater name");
                         i = Convert.ToInt32(Console.ReadLine());
                         if (i == 1)
                         {
                             R1.SearchByTheaterName();
                         }
                         else if (i == 2)
                         {
                             P1.SearchByTheaterName();
                         }
                         goto a;
                    case 6:
                         Console.WriteLine("1:RegularTheater\n 2:PVRTheater");
                         Console.WriteLine("Enter the Licence number");
                         i = Convert.ToInt32(Console.ReadLine());
                         if (i == 1)
                         {
                             R1.SearchByLicenceNumber();
                         }
                         else if (i == 2)
                         {
                             P1.SearchByLicenceNumber();
                         }
                         goto a;
                    case 7: break;
                    default: Console.WriteLine("Enter correct choice");
                        goto a;
                }
            }
            
        }
    }
