﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _496105_caselet
{
    class DueDateException : Exception
    {
        public DueDateException()
            : base("Patient has not cleared balance")
        {
        }
    }
}