﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _496105_caselet
{
    abstract class PatientDetails
    {
        string patientName;
        static int patientId = 0;

        int patIdStore;
        int patientAge;
        DateTime patientDOB;
        string patientAddress;
        string referringDoctor;

        public string PatientName
        {
            get { return patientName; }
            set { patientName = value; }
        }


        public int PatientId
        {
            get { return patientId; }
            set { patientId = value; }
        }

        public int PatIDStore
        {
            get { return patIdStore; }
            set { patIdStore = value; }
        }

        public int PatientAge
        {
            get { return patientAge; }
            set { patientAge = value; }
        }

        public DateTime PatientDOB
        {
            get { return patientDOB; }
            set { patientDOB = value; }
        }

        public string PatientAddress
        {
            get { return patientAddress; }
            set { patientAddress = value; }
        }

        public string ReferringDoctor
        {
            get { return referringDoctor; }
            set { referringDoctor = value; }
        }

        public abstract void GetPatientDetails();
        public abstract void AddPatientDetails();
        public abstract void RemovePatient();
    }
}