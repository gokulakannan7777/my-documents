﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace productcaselet
{
    class UnderflowException : ApplicationException
    {
        public override string Message
        {
            get
            {
                return "UnderFlowException \n No Data Found";
            }
        }
    }
}