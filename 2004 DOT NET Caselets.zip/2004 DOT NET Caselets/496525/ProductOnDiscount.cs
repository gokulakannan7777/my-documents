﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace productcaselet
{
    class ProductOnDiscount : Product, IProduct
    {
        public double DiscountPercentage { get; set; }
        public int MinimumPickQuantity { get; set; }
        List<Product> p = new List<Product>();
        List<ProductOnDiscount> pd = new List<ProductOnDiscount>();
        
        public void AddProduct()
        {
            Console.WriteLine("enter Product Name");
            StringBuilder MyStringBuilder = new StringBuilder(ProductName);
            ProductName = Console.ReadLine();
            Console.WriteLine("Enter Product Code");
            ProductCode = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Product Category Code");
            CategoryCode = Convert.ToInt32(Console.ReadLine());
            ProductCount += 1;

        }
        public void CopyAProduct(int pcode)
        {
            //int a;
            //Console.WriteLine("Enter the Productcode of project you want to move");
            //a = Convert.ToInt16(Console.ReadLine());
            //pd.AddRange(p.GetRange(0, a));
            //List<ProductOnDiscount> pd = p.GetRange(0, a);
           // var selected = from p in Product
 
           //                where p.Productcode>0   
           //                select p;

           ////pd.AddRange(selected);
            //var selected = p.Where(Product => Product.ProductCount > 10).ToList();
            //p = p.Except(selected).ToList();
            //pd.AddRange(p.GetRange(selected));
           
          
            
            
        }
        public override void ModifyProduct(int pcode)
        {
            ProductOnSale p = new ProductOnSale();
            if (p.ProductCode == pcode)
            {
                int a;
                Console.WriteLine("Press\n1.To Change Name of Product\n2.To change Product code\n3.To change Category Code\n4.To Change all\n5.To Exit without Changing");
                a = Convert.ToInt16(Console.ReadLine());
                switch (a)
                {
                    case 1:
                        Console.WriteLine("enter new product name");
                        ProductName = Console.ReadLine();
                        break;
                    case 2:
                        Console.WriteLine("enter new Product Code");
                        ProductCode = Convert.ToInt32(Console.ReadLine());
                        break;
                    case 3:
                        Console.WriteLine("enter new Category Code");
                        CategoryCode = Convert.ToInt32(Console.ReadLine());
                        break;
                    case 4:
                        Console.WriteLine("enter new ProductName\nProduct Code\nCategory Code");
                        ProductName = Console.ReadLine();
                        ProductCode = Convert.ToInt32(Console.ReadLine());
                        CategoryCode = Convert.ToInt32(Console.ReadLine());
                        break;
                    case 5:
                        Console.WriteLine("exiting . .. .. .. ..");
                        break;
                }
            }
        }
        public void ModifyProduct(string pName)
        {
            ProductOnSale p = new ProductOnSale();
            if (p.ProductName.Equals(pName))
            {
                int a;
                Console.WriteLine("Press\n1.To Change Name of Product\n2.To change Product code\n3.To change Category Code\n4.To Change all\n5.To Exit without Changing");
                a = Convert.ToInt16(Console.ReadLine());
                switch (a)
                {
                    case 1:
                        Console.WriteLine("enter new product name");
                        p.ProductName = Console.ReadLine();
                        break;
                    case 2:
                        Console.WriteLine("enter new Product Code");
                        p.ProductCode = Convert.ToInt32(Console.ReadLine());
                        break;
                    case 3:
                        Console.WriteLine("enter new Category Code");
                        p.CategoryCode = Convert.ToInt32(Console.ReadLine());
                        break;
                    case 4:
                        Console.WriteLine("enter new ProductName\nProduct Code\nCategory Code");
                        ProductName = Console.ReadLine();
                        ProductCode = Convert.ToInt32(Console.ReadLine());
                        CategoryCode = Convert.ToInt32(Console.ReadLine());
                        break;
                    case 5:
                        Console.WriteLine("exiting . .. .. .. ..");
                        break;
                }
            }
        }
        public void RemoveProduct(int pcode)
        {

        }
        public void RemoveProduct(string pname, int pcode)
        {

        }
        public int GetProductCode(string PName)
        {
            int pcode = 0;
            return pcode;
        }
        //public List<string> GetAllProductCodes()
        //{

        //    string pname=" ";
        //    return 
        //}
        public double GetDiscountPercent(int pcode)
        {
            double perc = 1.0;
          
            Console.WriteLine("Discount Percent is:{0}", perc);
            return perc;
        }
        public string GetProductDesc(int pcode)
        {
            string pname = "";
            return pname;
        }
        public int GetCategoryCode(int pcode)
        {
            int Ccode = 0;
            return Ccode;
        }
        public double GetQuantityOnSale()
        {
            double d = 10.00;
            return d;
        }
        public override string ToString()
        {
            return ProductCode + "\n" + ProductName + "\n" + CategoryCode;
        }
    }
}
