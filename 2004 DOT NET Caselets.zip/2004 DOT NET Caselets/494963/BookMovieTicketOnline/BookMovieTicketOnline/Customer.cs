﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BookingonlineMovietc
{
    public class Customer
    {
        private string name;
        public string Name { get { return name; } set { name = value; } }
        private DateTime birthDate;
        public DateTime BirthDate { get { return birthDate; } set { birthDate = value; } }
        private static int customerId = 1000;
        public int CustomerId { get { return customerId; } set { customerId = value; } }
        private int customerId2;
        public int CustomerId2 { get { return customerId2; } set { customerId2 = value; } }
        private string password;
        public string Password { get { return password; } set { password = value; } }
        private char gender;
        public char Gender { get { return gender; } set { gender = value; } }
        private double mobileNumber;
        public double MobileNumber { get { return mobileNumber; } set { mobileNumber = value; } }
        private string address;
        public string Address { get { return address; } set { address = value; } }
        private double zipCode;
        public double ZipCode { get { return zipCode; } set { zipCode = value; } }
        private string city;
        public string City { get { return city; } set { city = value; } }
        private string state;
        public string State { get { return state; } set { state = value; } }
        private string email;
        public string Email { get { return email; } set {email = value; } }


        public void NewCustomer(List<Customer> CustomerList)
        {
            //try
            //{
            bool WhileBooleanCondition = true;
            Customer CustomerObject = new Customer();
            int errorcount = 0;
            while (WhileBooleanCondition)
            {
                errorcount = 0;
                Console.WriteLine("Enter your Name");
                CustomerObject.Name = Console.ReadLine();
                for (int i = 0; i < CustomerObject.Name.Length; i++)
                    if (CustomerObject.Name[i] >= 'a' && CustomerObject.Name[i] <= 'z' || CustomerObject.Name[i] >= 'A' && CustomerObject.Name[i] <= 'Z')
                        WhileBooleanCondition = false;
                    else
                        errorcount++;
                if (errorcount > 0)
                {
                    WhileBooleanCondition = true;
                    new DataException();
                }
            }
            WhileBooleanCondition = true;
            while (WhileBooleanCondition)
            {
                try
                {
                    Console.WriteLine("Please Enter your Date of birth (DD-MM-YYYY)");
                    CustomerObject.BirthDate = Convert.ToDateTime(Console.ReadLine());
                    if (BirthDate.Year > 2014)
                    {
                        new DataException();
                    }
                    else
                    {
                        int age = (DateTime.Now.Year - CustomerObject.BirthDate.Year);
                        if (age >= 18)
                            WhileBooleanCondition = false;
                        else
                            new AgeException();
                    }
                }
                catch
                {
                    new DataException();
                }
            }
            WhileBooleanCondition = true;
            while (WhileBooleanCondition)
            {
                Console.WriteLine("Enter your gender in Upper case");
                
                CustomerObject.Gender = Convert.ToChar(Console.ReadLine());
                if (char.IsUpper(CustomerObject.Gender))
                {
                    if ((CustomerObject.Gender == 'M') || (CustomerObject.Gender == 'F'))
                        WhileBooleanCondition = false;
                    else
                        new DataException();
                }
                else
                    new DataException();
            }
            WhileBooleanCondition = true;
            Console.WriteLine("Enter your password");
            CustomerObject.Password = Console.ReadLine();
            while (WhileBooleanCondition)
            {
                Console.WriteLine("Enter 10 digit mobile number");
                CustomerObject.MobileNumber = Convert.ToInt64(Console.ReadLine());
                if (CustomerObject.MobileNumber > 7000000000 && CustomerObject.MobileNumber < 9999999999)
                    WhileBooleanCondition = false;
                else
                    new DataException();
            }
            WhileBooleanCondition = true;
            Console.WriteLine("Enter Email Address");
            CustomerObject.email = Console.ReadLine();
            Console.WriteLine("Enter Address");
            CustomerObject.Address = Console.ReadLine();
            Console.WriteLine("Enter City name");
            CustomerObject.City = Console.ReadLine();
            Console.WriteLine("enter State");
            CustomerObject.State = Console.ReadLine();
               
            Console.WriteLine("Enter Zip code");
            CustomerObject.ZipCode = Convert.ToInt64(Console.ReadLine());
            Console.WriteLine("\n\nYour Identification Number :\n");
            CustomerObject.CustomerId2 = ++CustomerId;
            Console.WriteLine(CustomerObject.CustomerId2);
            CustomerList.Add(CustomerObject);
     
        }
        public int Validation(int InputCustomerId, List<Customer> c)
        {
            int ValidatingVariable = 0;
            string InputPassword;
            if (InputCustomerId != 1)
            {
                foreach (Customer a in c)
                {
                    if (a.CustomerId2 == InputCustomerId)
                    {
                        Console.WriteLine("Enter your password");
                        InputPassword = Console.ReadLine();
                        if (a.Password == InputPassword)
                        {
                            ValidatingVariable = 1;
                        }
                    }
                }
            }
            else if (InputCustomerId == 1)
            {
                Console.WriteLine("Enter your Password");
                InputPassword = Console.ReadLine();
                if (InputPassword == "123")
                {
                    ValidatingVariable = 2;
                }

            }
            return ValidatingVariable;
        }
        internal void Getdetails(int RequestedCustomerId, List<Customer> PassedCustomerList)
        {
            foreach (Customer CustomerObject in PassedCustomerList)
            {
                int Age = (DateTime.Now.Year - BirthDate.Year);
                Console.WriteLine("*****************");
                Console.WriteLine("Personal details");
                Console.WriteLine("Name:\t{0}\nGender:\t{1}\nMobile number:\t{2}\nAge:\t{3}\n", CustomerObject.Name, CustomerObject.Gender, CustomerObject.MobileNumber, Age);
                Console.WriteLine("Address details");
                Console.WriteLine("Address:\t{0}\nCity:\t{1}\nState:\t{2}\nZipcode:\t{3}", CustomerObject.Address, CustomerObject.City, CustomerObject.State, CustomerObject.ZipCode);
            }
        }
        internal void Getalldetails(List<Customer> PassedCustomerList)
        {
            int CheckVariable = 0;
            Console.WriteLine("********************");
            foreach (Customer CustomerObject in PassedCustomerList)
            {
                int Age = (DateTime.Now.Year - CustomerObject.BirthDate.Year);
                Console.WriteLine("\nPersonal details");
                Console.WriteLine("Name:\t{0}\nGender:\t{1}\nMobile number:\t{2}\nAge:\t{3}\n", CustomerObject.Name, CustomerObject.Gender, CustomerObject.MobileNumber, Age);
                Console.WriteLine("Address details");
                Console.WriteLine("Address:\t{0}\nCity:\t{1}\nState:\t{2}\nZipcode:\t{3}", CustomerObject.Address, CustomerObject.City, CustomerObject.State, CustomerObject.ZipCode);
                CheckVariable++;
            }
            if (CheckVariable == 0)
                new Exception();
        }
    }
}
