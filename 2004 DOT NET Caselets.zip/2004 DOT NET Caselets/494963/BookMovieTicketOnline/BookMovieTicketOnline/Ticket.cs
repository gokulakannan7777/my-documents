﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BookingonlineMovietc
{
    public partial class Ticket
    {
        private static int ticketId = 10000;
        int Ticketid { get { return ticketId; } set { ticketId = value; } }
        private int theatreName;
        public int TheatreName { get { return theatreName; } set { theatreName = value; } }
        private int movieName;
        public int MovieName { get { return movieName; } set { movieName = value; } }
        private DateTime showDetails;
        public DateTime ShowDetails { get { return showDetails; } set { showDetails = value; } }
        private DateTime showTime;
        private DateTime showDate;
        public DateTime ShowDate { get { return showDate; } set { showDate = value; } }

        public DateTime ShowTime { get { return showTime; } set { showTime = value; } }
        private int seatNo;
        int Seatno { get { return seatNo; } set { seatNo = value; } }
        private int numberofSeats;
        public int NumberofSeats { get { return numberofSeats; } set { numberofSeats = value; } }
        public int OrdrId;
        public Ticket()
        { }

        internal void ticketdetails(List<Ticket> t)
        {
            //int ordrch = 1;
            int check = 0;
            int ticketAmount = 0;
            string nameTheatre = "";
            string nameMovie = "";
            foreach (Ticket tic in t)
            {
                Console.WriteLine("Ticket id is\t{0}", tic.Ticketid);
                Console.WriteLine("Orderid \t{0}", tic.OrdrId);
                if (tic.TheatreName == 1)
                {
                    nameTheatre = "PVP";
                    ticketAmount = 100;
                }
                else if (tic.TheatreName == 2)
                {
                    nameTheatre = "PVR";
                    ticketAmount = 150;
                }
                else if (tic.TheatreName == 3)
                {
                    nameTheatre = "INOX";
                    ticketAmount = 130;
                }
                Console.WriteLine("Theatre name \t{0}", nameTheatre);
                if (tic.MovieName == 1)
                    nameMovie = "abc";
                else if (tic.MovieName == 2)
                    nameMovie = "xxx";
                else if (tic.MovieName == 3)
                    nameMovie = "yyy";
                Console.WriteLine("Movie name \t {0}", nameMovie);
                Console.WriteLine("No of tickets ordered\t{0}", tic.NumberofSeats);
                Console.WriteLine("Amount for tickets: {0}", ticketAmount * tic.NumberofSeats);
                check++;
            }
            if (check == 0)
            {
                new Exception();
            }
        }
    }
}
