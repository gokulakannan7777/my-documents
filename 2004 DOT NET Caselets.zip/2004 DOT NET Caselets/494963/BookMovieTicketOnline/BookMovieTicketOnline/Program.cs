﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace BookingonlineMovietc
{
    public class Program
    {
        public static List<Customer> b = new List<Customer>();
        public static List<Order> a = new List<Order>();
        public static List<Transaction> c = new List<Transaction>();
        public static List<Ticket> t = new List<Ticket>();
        static void Main(string[] args)
        {
            Console.WriteLine("\t\t\t WELCOME  TO BOOKMYSHOW \n ");
            int InnerDoWhileChoice;
            Ticket TicketObject = new Ticket();
            Customer CustomerObject = new Customer();
            Order OrderObject = new Order();
            Admin AdministratorObject = new Admin();
            int SwitchcaseChoice;
            int DoWhileChoice = 0;
            try
            {
                do
                {
                   
                    Console.WriteLine("Enter your Choice\n");
                    Console.WriteLine("1.Register\n2.Sign In\n");
                    SwitchcaseChoice = Convert.ToInt32(Console.ReadLine());
                    switch (SwitchcaseChoice)
                    {
                        case 1:
                            CustomerObject.NewCustomer(b);
                            break;
                        case 2:
                            Console.WriteLine("Enter your ID");
                            int InputCustomerId = Convert.ToInt32(Console.ReadLine());
                            int Validation = CustomerObject.Validation(InputCustomerId, b);
                            try
                            {
                                if (Validation == 1)
                                {
                                    do
                                    {
                                        Console.WriteLine("Enter\t 1.To see order amount\n\t\t2.To place orders\n\t\t   3.To view Account details");
                                        int ch = Convert.ToInt32(Console.ReadLine());
                                        switch (ch)
                                        {
                                            case 1:
                                                OrderObject.Gettransactionamount(a, c);
                                                break;
                                            case 2:
                                                Console.WriteLine("\nPlace your order");
                                                OrderObject.Placeorder(InputCustomerId, a, c, t);
                                                break;
                                            case 3:
                                                CustomerObject.Getdetails(InputCustomerId, b);
                                                break;
                                            default:
                                                new ChoiceException();
                                                break;
                                        }
                                        Console.WriteLine("\n\nEnter 1 for another transaction\n\t other to logout\n");
                                        InnerDoWhileChoice = Convert.ToInt32(Console.ReadLine());
                                    } while (InnerDoWhileChoice == 1);
                                    Console.WriteLine("\n\nSuccessfully Logged out\n");
                                }
                                else if (Validation == 2)
                                {
                                    AdministratorObject.Start(a, b, c, t);
                                }
                                else
                                {
                                    throw new ValidationException();
                                }
                            }
                            catch
                            { }
                            break;
                        default:
                            new ChoiceException();
                            break;
                    }
                    Console.WriteLine("\nEnter 1 to continue");
                    DoWhileChoice = Convert.ToInt32(Console.ReadLine());
                } while (DoWhileChoice == 1);
            }
            catch
            {
                new ChoiceException();
            }

        }
    }
}

