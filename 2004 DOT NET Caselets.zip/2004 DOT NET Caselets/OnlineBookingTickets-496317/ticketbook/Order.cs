﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ticketbook
{
    public class Order
    {

        private static int orderNo = 10000;
        public int Orderno 
        {
            get 
            { 
                return orderNo; 
            } 
            set
            { 
                orderNo = value; 
            } 
        }
        private int orderNo2;
        public int OrderNo2 
        { 
            get 
            { 
                return orderNo2; 
            }
            set 
            { 
                orderNo2 = value; 
            } 
        }
        private DateTime orderDatetime;
        public DateTime OrderDateandTime 
        { 
            get
            { 
                return orderDatetime; 
            }
            set 
            { 
                orderDatetime = DateTime.Now; 
            } 
        }
        private int customerId2;
        public int CustomerId2 
        {
            get
            { 
                return customerId2;
            } 
            set 
            { 
                customerId2 = value; 
            } 
        }
        int TransactionId2;
        Ticket TicketObject2 = new Ticket();
        Transaction TransactionObject2 = new Transaction();
        public void Placeorder(int InputCustomerId, List<Order> PassedOrderList, List<Transaction> PassedTransactionList, List<Ticket> PassedTicketList)
        {
            Order O = new Order();
            O.OrderNo2 = ++Orderno;
            O.CustomerId2 = InputCustomerId;
            O.OrderDateandTime = DateTime.Now;
            int amount = TicketObject2.getticket(Orderno, PassedTicketList);
            if (amount != 0)
            {
                O.TransactionId2 = TransactionObject2.NewTransaction(Orderno, PassedTransactionList, amount);
                PassedOrderList.Add(O);
                Console.WriteLine("\nOrderid is  {0}", O.OrderNo2);
                Console.WriteLine("Your transaction id is  {0} ", O.TransactionId2);
            }
            else
            {
                new Exception();
            }
        }
        public void Gettransactionamount(List<Order> PassedOrderList, List<Transaction> PassedTransactionList)
        {
            int i = 0;
            foreach (Order Orderobject in PassedOrderList)
            {
                Console.WriteLine("\nEnter order id ");
                int o = Convert.ToInt32(Console.ReadLine());
                if (o == Orderobject.OrderNo2)
                {
                    i++;
                    TransactionObject2.gettransaction(o, PassedTransactionList);
                }
            }
            if (i == 0)
            {
                new Exception();
            }
        }
        public void Getorders(List<Order> PassedOrderList, List<Transaction> PassedTransactionList)
        {
            int check = 1;
            bool BooleanVariableInnerWhileLoop = true;
            bool BooleanVariableOuterWhileLoop = true;
            DateTime TransactionStartDate = DateTime.Now;
            DateTime TransactionEndDate = DateTime.Now;
            foreach (Order Orderobject in PassedOrderList)
            {
                while (BooleanVariableOuterWhileLoop)
                {
                    while (BooleanVariableInnerWhileLoop)
                    {
                        try
                        {
                            Console.WriteLine("Please enter starting date");
                            TransactionStartDate = Convert.ToDateTime(Console.ReadLine());
                            BooleanVariableInnerWhileLoop = false;
                        }
                        catch
                        {
                            new DateException();
                        }
                    }
                    BooleanVariableInnerWhileLoop = true;
                    while (BooleanVariableInnerWhileLoop)
                    {
                        try
                        {
                            Console.WriteLine("Please enter ending date");
                            TransactionEndDate = Convert.ToDateTime(Console.ReadLine());
                            BooleanVariableInnerWhileLoop = false;
                        }
                        catch
                        {
                            new DateException();
                        }
                    }
                    BooleanVariableInnerWhileLoop = true;
                    if (TransactionEndDate > TransactionStartDate)
                    {
                        BooleanVariableOuterWhileLoop = false;

                        if ((DateTime.Now > TransactionStartDate) && (DateTime.Now < TransactionEndDate))
                        {
                            Console.WriteLine(Orderobject.OrderNo2);
                            TransactionObject2.gettransaction(Orderobject.OrderNo2, PassedTransactionList);
                            check++;
                        }
                    }
                    else
                    {
                        check = 0;
                        new DateException();
                    }

                }
            }
            if (check == 1)
            {
                Console.WriteLine("No orders in the time");
            }

        }
    }

}