﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ticketbook
{
    class AgeException : ApplicationException
    {
        public AgeException()
            
        {
            Console.WriteLine("\n Your age should be above 18 ");
        }
    }
    class Exception : ApplicationException
    {
        public Exception()
            
        {
            Console.WriteLine("\n No details to display");
        }
    }
    class DataException : ApplicationException
    {
        public DataException() 
            
        {
            Console.WriteLine("\nEntered invalid data");
        }
    }

    class ChoiceException : ApplicationException
    {
        public ChoiceException() 
         
        {
            Console.WriteLine("\nEntered choice doesn't exist");
        }
    }
    class ValidationException : ApplicationException
    {
        public ValidationException() 
            
        {
            Console.WriteLine("\nInvalid Credentials");
        }
    }
    class DateException : ApplicationException
    {
        public DateException() 
           
        {
            Console.WriteLine("Entered invalid date ");
        }
    }
}
