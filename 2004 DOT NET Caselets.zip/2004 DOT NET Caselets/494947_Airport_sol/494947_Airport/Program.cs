﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _494947_Airport
{
    abstract class AirportEssentials
    {
        public string AirportName;
        public  int AirportID;
        
        public string CityName;
        public int AllotedAreaforAirport;
        public int AllotedAreaforParking;
        public string Address;
        
        public abstract void AddNewAirport();
        public abstract void RemoveAirport();
        public abstract void EditAirportDetails();
        public abstract void GetDetailsForNewAirport();
        public abstract void ShowAirportDetails();

    }
    class MinRequiredLandException : ApplicationException
    {
        public void displaymsg1()
        {
            Console.WriteLine("The avaiable land is below the minimum required land");
        }
    }
    class MinNoofFlightsADayException : ApplicationException
    {
        public void displaymsg2()
        {
            Console.WriteLine("The no. of flights are less than the minimum no of flights a day");
        }
    }
    class MaxNoofFlightsADayException : ApplicationException
    {
        public void displaymsg3()
        {
            Console.WriteLine("The no. of flights are more than the maximum no of flights a day");
        }
    }
    class DomesticAirport:AirportEssentials
    {

        int MinRequiredAirStripLength;
        int MinNoOfFlightsADay;
        int MaxNoOfFlightsADay;
        int DistanceFromCity;
        List<DomesticAirport> DA_List = new List<DomesticAirport>();
        
           int j=0;
           public static readonly int num = 100; 
        
        public override void AddNewAirport()
        {
            DomesticAirport d = new DomesticAirport();
            Console.WriteLine("Enter the Airport name ");
            d.AirportName = Console.ReadLine();
            Console.WriteLine("Enter the city name ");
            d.CityName = Console.ReadLine();
            Console.WriteLine("Enter the Address ");
            d.Address = Console.ReadLine();
            d.AirportID = num + j++;
            Console.WriteLine("Airport ID is {0}", d.AirportID);
            DA_List.Add(d);
            

            

        }
        public override void RemoveAirport()
        {
            int a;
            Console.WriteLine("Enter the AirportID to be removed");
            a = Convert.ToInt32(Console.ReadLine());
          
            bool temp = false;
            for (int i = 0; i < DA_List.Count; i++)
            {
                if (DA_List[i].AirportID == a)
                {
                    temp = true;
                    DA_List.RemoveAt(i);
                       
                }
            }
            if (temp == false)
            {
                Console.WriteLine("Invalid AirportID");
            }
        }
        public override void EditAirportDetails()
        {
            bool isEmpty = !DA_List.Any();
            if (isEmpty)
            {
                Console.WriteLine("No Airport Details were added");
            }
           
            int b;
            Console.WriteLine("Enter the AirportID to be edited");
            b = Convert.ToInt32(Console.ReadLine());
            foreach (DomesticAirport x in DA_List)
            {
                if (b == x.AirportID)
                {
                    int c;
                    Console.WriteLine("Edit 1.Airport Name 2.City Name 3.Address ");
                    c = Convert.ToInt32(Console.ReadLine());
                    switch (c)
                    {
                        case 1: x.AirportName = Console.ReadLine(); break;
                        case 2: x.CityName = Console.ReadLine(); break;
                        case 3: x.Address = Console.ReadLine(); break;
                        default: Console.WriteLine("Enter valid selection"); break;
                    }
                }
               
                
                else
                {
                    Console.WriteLine("Enter Correct AirportID ");
                }
            }

        }

        public override void GetDetailsForNewAirport()
        {
            int b;
            Console.WriteLine("Enter the AirportID to add details");
            b = Convert.ToInt32(Console.ReadLine());
            foreach (DomesticAirport x in DA_List)
            {
                if (b == x.AirportID)
                {
                  
                    Console.WriteLine("Enter Alloted Area for Airport");
                    x.AllotedAreaforAirport = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Alloted Area for Parking");
                    x.AllotedAreaforParking = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter minimum required airstriplength ");
                     x.MinRequiredAirStripLength = Convert.ToInt32(Console.ReadLine());
                   
                    try
                    {
                        if (x.MinRequiredAirStripLength < 500)
                        {
                            MinRequiredLandException e1 = new MinRequiredLandException();
                            throw (e1);

                        }
                    }
                    catch (MinRequiredLandException e)
                    {
                        e.displaymsg1();
                    }
                    Console.WriteLine("Enter minimum no. of flights a day");
                    x.MinNoOfFlightsADay = Convert.ToInt32(Console.ReadLine());
                    try
                    {
                        if (x.MinNoOfFlightsADay > 50)
                        {
                            MinNoofFlightsADayException e1 = new MinNoofFlightsADayException();
                            throw (e1);
                        }
                    }
                    catch (MinNoofFlightsADayException e)
                    {
                        e.displaymsg2();
                    }
                    Console.WriteLine("Enter maximum no. of flights a day");
                    x.MaxNoOfFlightsADay = Convert.ToInt32(Console.ReadLine());
                    try
                    {
                        if (x.MaxNoOfFlightsADay > 50)
                        {
                            MaxNoofFlightsADayException e1 = new MaxNoofFlightsADayException();
                            throw (e1);
                        }
                    }
                    catch (MaxNoofFlightsADayException e)
                    {
                        e.displaymsg3();
                    }

                    Console.WriteLine("Enter distance from city");
                    x.DistanceFromCity = Convert.ToInt32(Console.ReadLine());
                   
                }
                else
                {
                    Console.WriteLine("Enter correct AirportID");
                }
            }
            
        }
        
        public override void ShowAirportDetails()
        {
            
            foreach (DomesticAirport x in DA_List)
            {

                Console.WriteLine("AirPort ID :{0}", x.AirportID);
                Console.WriteLine("AirPort Name :{0}", x.AirportName);
                Console.WriteLine("Address:{0}", x.Address);
                Console.WriteLine("City Name:{0}", x.CityName);
              
            }
           
        }




    }
    class InternationalAirport: AirportEssentials
    {

        int MinRequiredAirStripLength;
        int MinNoOfFlightsADay;
        int MaxNoOfFlightsADay;
        int DistanceFromCity;
        int MinNoofAirBridge;
        List<InternationalAirport> IA_List = new List<InternationalAirport>();
        public static readonly int no = 200;
        int k = 0;
        public override void AddNewAirport()
        {
            InternationalAirport ia = new InternationalAirport();
            Console.WriteLine("Enter the Airport name ");
            Console.WriteLine("Enter the city name ");
            ia.CityName = Console.ReadLine();
            Console.WriteLine("Enter the Address ");
            ia.Address = Console.ReadLine();
            ia.AirportName = Console.ReadLine();

            ia.AirportID = no + k++;
            Console.WriteLine("Airport ID is {0}", ia.AirportID);
            IA_List.Add(ia);

             }
        public override void RemoveAirport()
        {
            int a;
            Console.WriteLine("Enter the AirportID to be removed");
            a = Convert.ToInt32(Console.ReadLine());

            bool temp = false;
            for (int i = 0; i < IA_List.Count; i++)
            {
                if (IA_List[i].AirportID == a)
                {
                    temp = true;
                    IA_List.RemoveAt(i);

                }
            }
            if (temp == false)
            {
                Console.WriteLine("Invalid AirportID");
            }
        }
        public override void EditAirportDetails()
        {
            bool isEmpty = !IA_List.Any();
            if (isEmpty)
            {
                Console.WriteLine("No Airport Details were added");
            }
            int b;
            Console.WriteLine("Enter the AirportID to be edited");
            b = Convert.ToInt32(Console.ReadLine());
            foreach (InternationalAirport x in IA_List)
            {
                if (b == x.AirportID)
                {
                    int c;
                    Console.WriteLine("Edit 1.Airport Name 2.City Name 3.Address ");
                    c = Convert.ToInt32(Console.ReadLine());
                    switch (c)
                    {
                        case 1: x.AirportName = Console.ReadLine(); break;
                        case 2: x.CityName = Console.ReadLine(); break;
                        case 3: x.Address = Console.ReadLine(); break;
                        default: Console.WriteLine("Enter valid selection"); break;
                    }
                    
                    Console.WriteLine("Airport details are updated Successfully");
                }
                else
                {
                    Console.WriteLine("Enter correct AirportID");
                }
            }
        }

        public override void GetDetailsForNewAirport()
        {
            int b;
            Console.WriteLine("Enter the AirportID to add details");
            b = Convert.ToInt32(Console.ReadLine());
            foreach (InternationalAirport x in IA_List)
            {
                if (b == x.AirportID)
                {
                  
                    Console.WriteLine("Enter Alloted Area for Airport");
                    x.AllotedAreaforAirport = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Alloted Area for Parking");
                    x.AllotedAreaforParking = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter minimum required airstriplength ");
                    x.MinRequiredAirStripLength = Convert.ToInt32(Console.ReadLine());

                    try
                    {
                        if (x.MinRequiredAirStripLength < 500)
                        {
                            MinRequiredLandException e1 = new MinRequiredLandException();
                            throw (e1);

                        }
                    }
                    catch (MinRequiredLandException e)
                    {
                        e.displaymsg1();
                    }
                    Console.WriteLine("Enter minimum no. of flights a day");
                    x.MinNoOfFlightsADay = Convert.ToInt32(Console.ReadLine());
                    try
                    {
                        if (x.MinNoOfFlightsADay > 50)
                        {
                            MinNoofFlightsADayException e1 = new MinNoofFlightsADayException();
                            throw (e1);
                        }
                    }
                    catch (MinNoofFlightsADayException e)
                    {
                        e.displaymsg2();
                    }
                    Console.WriteLine("Enter maximum no. of flights a day");
                    x.MaxNoOfFlightsADay = Convert.ToInt32(Console.ReadLine());
                    try
                    {
                        if (x.MaxNoOfFlightsADay > 50)
                        {
                            MaxNoofFlightsADayException e1 = new MaxNoofFlightsADayException();
                            throw (e1);
                        }
                    }
                    catch (MaxNoofFlightsADayException e)
                    {
                        e.displaymsg3();
                    }
                    Console.WriteLine("Enter minimum no. of air bridge");
                    x.MinNoofAirBridge = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter distance from city");
                    x.DistanceFromCity = Convert.ToInt32(Console.ReadLine());
                  
                   
                   
                }
                else
                {
                    Console.WriteLine("Enter correct AirportID");
                }
            }

        }

        public override void ShowAirportDetails()
        {

            foreach (InternationalAirport x in IA_List)
            {

                Console.WriteLine("AirPort ID :{0}", x.AirportID);
                Console.WriteLine("AirPort Name :{0}", x.AirportName);
                Console.WriteLine("Address:{0}", x.Address);
                Console.WriteLine("City Name:{0}", x.CityName);
           

            }

        }

    }
   
    class Program
    {
        static void Main(string[] args)
        {

            int x = 1;
            DomesticAirport DA = new DomesticAirport();
            InternationalAirport IA = new InternationalAirport();
            while (x == 1)
            {
               
                Console.WriteLine("Select Type of Airport: \n1.Domestic Airport \n2.Internatinal Airport \n3.Exit");
                int ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        {
                            int y = 1;
                            while (y == 1)
                            {

                                Console.WriteLine("\n");
                                Console.WriteLine("Select the option to be Performed on Domestic Type of Airport:");
                                Console.WriteLine("1.Add New Airport  \n2.Remove Airport \n3.Edit Airport Details\n4.Get Details for New Airport\n5.Show Airport Details \n6.Exit");
                                int ch1 = Convert.ToInt32(Console.ReadLine());

                                switch (ch1)
                                {
                                    case 1:
                                        {
                                            DA.AddNewAirport();
                                            break;
                                        }
                                    case 2:
                                        {
                                            DA.RemoveAirport();
                                            break;
                                        }
                                    case 3:
                                        {
                                            
                                            DA.EditAirportDetails();
                                            break;
                                        }
                                    case 4:
                                        {
                                            DA.GetDetailsForNewAirport();
                                            break;
                                        }
                                    case 5:
                                        {
                                            DA.ShowAirportDetails();
                                            break;
                                        }
                                    case 6:
                                        {
                                            y = 0;
                                            break;
                                        }
                                    default:
                                        {
                                            Console.WriteLine("Enter correct choice");
                                            y = 1;
                                            break;
                                        }
                                }
                            }
                            break;

                        }
                    case 2:
                        {
                            int y = 1;
                            while (y == 1)
                            {

                                Console.WriteLine("\n");
                                Console.WriteLine("Select the option to be Performed on International Type of Airport:");
                                Console.WriteLine("1.Add New Airport  \n2.Remove Airport \n3.Edit Airport Details\n4.Get Details for New Airport\n5.Show Airport Details \n6.Exit");
                                int ch1 = Convert.ToInt32(Console.ReadLine());

                                switch (ch1)
                                {
                                    case 1:
                                        {
                                            IA.AddNewAirport();
                                            break;
                                        }
                                    case 2:
                                        {
                                            IA.RemoveAirport();
                                            break;
                                        }
                                    case 3:
                                        {
                                         
                                            IA.EditAirportDetails();
                                            break;
                                        }
                                    case 4:
                                        {
                                            IA.GetDetailsForNewAirport();
                                            break;
                                        }
                                    case 5:
                                        {
                                            IA.ShowAirportDetails();
                                            break;
                                        }
                                    case 6:
                                        {
                                            y = 0;
                                            break;
                                        }
                                    default:
                                        {
                                            Console.WriteLine("Enter correct choice");
                                            y = 1;
                                            break;
                                        }
                                }
                            }
                            break;

                        }
                    case 3: x = 0; break;
                    default: Console.WriteLine("Choose the correct option"); break;

                       
                       

                }
            }
        }
    }
}


