﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace _496293_Flight
{

    class Program
    {
        static void Main(string[] args)
        {
            Commercial_Flight cf1 = new Commercial_Flight();
            CharterFlight cf2 = new CharterFlight();
            int boundary = 0;
            try
            {
                while (boundary == 0)
                {
                    int choice = 3;
                    Console.WriteLine("****Flight Management****");
                    Console.WriteLine("\nSelect a Flight Type:\n \n1.Commercial Flight  \n2.Charter Flight \n3.Exit");
                    choice = Convert.ToInt32(Console.ReadLine());
                    if (choice < 1 && choice > 3)
                    {
                        Console.WriteLine("Invalid Choice\n");
                    }

                    switch (choice)
                    {

                        case 1:

                            Console.WriteLine("\n1.Add Flight \n2.Remove Flight \n3.Calculate Duration \n4.Get Flight Details \n5.Get Source \n6.Get Destination \n7.Get Start Time \n8.GetDuration \n9.Get Seat Availability \n10.Available flights \n11.Previous Menu");
                            int ch = 10;
                            ch = Convert.ToInt32(Console.ReadLine());

                            switch (ch)
                            {
                                case 1:
                                    string flighttype = "Commercial";
                                    cf1.AddFlight(flighttype);
                                    break;
                                case 2: cf1.RemoveFlight();
                                    break;
                                case 3: cf1.CalculateDuration();
                                    break;
                                case 4: cf1.GetFlightDetails();
                                    break;
                                case 5: cf1.GetSource();
                                    break;
                                case 6: cf1.GetDestination();
                                    break;
                                case 7: cf1.GetStartTime();
                                    break;
                                case 8: cf1.GetDuration();
                                    break;
                                case 9:
                                    Console.WriteLine("Enter the Number of seats required: ");
                                    int a = Convert.ToInt32(Console.ReadLine());
                                    cf1.GetAvailability(a);
                                    break;
                                case 10:
                                    cf1.listofavailableflights();
                                    break;
                                case 11:
                                    break;
                                default: Console.WriteLine("Incorrect Option\n");
                                    break;
                            }
                            break;

                        case 2:
                            Console.WriteLine("\n1.Add Flight \n2.Remove Flight \n3.Calculate Duration \n4.Get Flight Details \n5.Previous Menu");
                            int ch2 = 5;
                            ch2 = Convert.ToInt32(Console.ReadLine());


                            switch (ch2)
                            {
                                case 1:
                                    string flighttype = "Charter ";
                                    cf2.AddFlight(flighttype);
                                    break;
                                case 2: cf2.RemoveFlight();
                                    break;
                                case 3: cf2.CalculateDuration();
                                    break;
                                case 4: cf2.GetFlightDetails();
                                    break;
                                case 5: break;
                                default: Console.WriteLine("Incorrect Option\n");
                                    break;
                            }
                            break;
                        case 3: boundary = 1;
                            break;
                        default: Console.WriteLine("Incorrect Option\n");
                            break;
                    }


                }
            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}


