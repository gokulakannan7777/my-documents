﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _496293_Flight
{
   
        class SameSourceAndDestinationException : ApplicationException
        {
            public override string Message
            {
                get
                {
                    return "Same Source and Destination\n";
                }
            }
        }
        class InvalidDetailsException : ApplicationException
        {
            public override string Message
            {
                get
                {
                    return "Invalid Details Entered\n";
                }
            }
        }
        class EmptyString : ApplicationException
        {
            public override string Message
            {
                get
                {
                    return "Invalid String Input\n";
                }
            }
        }

        class FlightNotFoundException : ApplicationException
        {
            public override string Message
            {
                get
                {
                    return "No Flight Found\n";
                }
            }
        }
    
}
