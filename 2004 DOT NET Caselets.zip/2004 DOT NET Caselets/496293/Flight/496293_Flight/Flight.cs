﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _496293_Flight
{
    abstract class Flight
    {

        private int flightno;
        private string type;
        private int seatingcapacity;
        private DateTime starttime;
        private int durationInMins;
        private int distance;
        private float speed;

        public int FlightNo
        {
            get { return flightno; }
            set { flightno = value; }
        }

        public string Type
        {
            get { return type; }
            set { type = value; }
        }

        public int SeatingCapacity
        {
            get { return seatingcapacity; }
            set { seatingcapacity = value; }
        }
        public DateTime StartTime
        {
            get { return starttime; }
            set { starttime = value; }
        }
        public int DurationInMins
        {
            get { return durationInMins; }
            set { durationInMins = value; }
        }
        public int Distance
        {
            get { return distance; }
            set { distance = value; }
        }
        public float Speed
        {
            get { return speed; }
            set { speed = value; }
        }


        public abstract void AddFlight(string type);
        public abstract void RemoveFlight();
        public abstract void CalculateDuration();
        

    }
}



