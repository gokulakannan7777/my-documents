﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _496498_HospitalManagementApp
{
    class Program
    {
        static void Main(string[] args)
        {
            DoctorDetails docDet = new DoctorDetails();
            InPatient inPat = new InPatient();
            OutPatient outPat = new OutPatient();
            Console.WriteLine("Select your choice!");
            int x = 0, choice1;
            while (x == 0)
            {
                Console.WriteLine("1. Doctor Details\n2. In Patient\n3. Out Patient\n4. Exit");
                while (true)
                {
                    try
                    {
                        choice1 = Convert.ToInt32(Console.ReadLine());
                        break;
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("enter valid choice");

                    }
                }
                switch (choice1)
                {
                    case 1:
                        {
                            int y = 0, ch;
                            while (y == 0)
                            {
                                Console.WriteLine("\n");
                                Console.WriteLine("1. Add Doctor Details\n2. Get Doctor Details\n3. Exit");
                                while (true)
                                {
                                    try
                                    {
                                        ch = Convert.ToInt32(Console.ReadLine());
                                        break;
                                    }
                                    catch (Exception)
                                    {
                                        Console.WriteLine("enter valid choice");

                                    }
                                }

                                switch (ch)
                                {
                                    case 1:
                                        docDet.AddDoctorDetails();
                                        break;
                                    case 2:

                                        docDet.GetDoctorDetails();
                                        break;
                                    case 3:
                                        y = 1;
                                        break;
                                }
                            }
                        }
                        break;
                    case 2:
                        {
                            int y = 0, choice2;
                            while (y == 0)
                            {
                                Console.WriteLine("\n");
                                Console.WriteLine("1.Add Patient Details\n2. Get Patient Details\n3. Remove Patient\n4. Exit");
                                while (true)
                                {
                                    try
                                    {
                                        choice2 = Convert.ToInt32(Console.ReadLine());
                                        break;
                                    }
                                    catch (Exception)
                                    {
                                        Console.WriteLine("enter valid choice");
                                    }
                                }

                                switch (choice2)
                                {
                                    case 1: inPat.AddPatientDetails();
                                        break;
                                    case 2: inPat.GetPatientDetails();
                                        break;
                                    case 3: inPat.RemovePatient();
                                        break;
                                    case 4:
                                        y = 1;
                                        break;
                                }
                            }
                        }
                        break;
                    case 3:
                        int endLoop1 = 1, choice;
                        while (endLoop1 == 1)
                        {
                            Console.WriteLine("\n");
                            Console.WriteLine("1.Add Patient Details\n2. Get Patient Details\n3. Remove Patient\n4. Get Bill\n5. Exit");
                            while (true)
                            {
                                try
                                {
                                    choice = Convert.ToInt32(Console.ReadLine());
                                    break;
                                }
                                catch (Exception)
                                {
                                    Console.WriteLine("enter valid choice");

                                }
                            }
                            switch (choice)
                            {
                                case 1: outPat.AddPatientDetails();
                                    break;
                                case 2: outPat.GetPatientDetails();
                                    break;
                                case 3: outPat.RemovePatient();
                                    break;
                                case 4:
                                    outPat.GetBill();
                                    break;
                                case 5: endLoop1 = -1;
                                    break;
                            }
                        }
                        break;
                    case 4:
                        x = 1;
                        break;
                }
            }
        }
    }
}