﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _496114
{
    //interface InvoicedItem
    //{
    //    int price;
    //    int discount;
    //    int warranty;.
    //    int xchangeperiod;
    //}
    interface IItem
    {

        void Getdiscount(int ICode);

        void GetPrice(int ICode);

        void GetXChangePeriod();

    }

    public class Item
    {
        public string ProductCode { get; set; }
        public int Itemcode { get; set; }
        public string Weight { get; set; }
        public int UOM { get; set; }

        public void AddItem() {}
        public void RemoveItem()
        {
            
        }
        public void convert()
        {
            Console.WriteLine("enter the weight of the items in liters");
            UOM= Convert.ToInt32(Console.ReadLine());
            double scalingfactor = 1.1;
            double wt = UOM / scalingfactor;
            Console.WriteLine("weight after conversion is:{0}", wt);
        }

    }
    public class InvoicedItem : Item
    {

        public int Price { get; set; }
        public int Discount { get; set; }
        public int Warranty { get; set; }
        public int XChangePeriod { get; set; }

        List<InvoicedItem> li = new List<InvoicedItem>();
        public int price1;
        public InvoicedItem()
        {

        }
        public void AddItem()
        {
            InvoicedItem a = new InvoicedItem();

            b:Console.WriteLine("enter the price of the product ");
            a.Price = Convert.ToInt32(Console.ReadLine());
            if (a.Price > 0)
            {
                Console.WriteLine("enter the discount for the product ");
                a.Discount = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter the warranty for the product ");
                a.Warranty = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter the period for exchanging the product ");
                a.XChangePeriod = Convert.ToInt32(Console.ReadLine());
            }
            else if (a.Price < 0)
            {
                Console.WriteLine("The price of the product as a positive value");
                goto b;
            }
            Console.WriteLine("add new item code");
            a.Itemcode = Convert.ToInt32(Console.ReadLine());
            li.Add(a);
        }
        public void RemoveItem()
        {
            bool t = false;
            Console.WriteLine("Enter the item code ");
            int temp = Convert.ToInt32(Console.ReadLine());
            foreach (InvoicedItem i in li)
            {
                if (i.Itemcode == temp)
                {
                    t = true;
                    li.Remove(i);
                    Console.WriteLine("Item deleted");
                    return;
                }
            }
            if (t == false)
            {
                Console.WriteLine("Invalid item code");
            }
        }
        public void calculatediscount()
        {
            bool t = false;
            Console.WriteLine("Enter the item code ");
            int temp = Convert.ToInt32(Console.ReadLine());
            foreach (InvoicedItem i in li)
            {
                if (i.Itemcode == temp)
                {
                    t = true;
                    i.Price = i.Price - (i.Price * i.Discount / 100);
                    Console.WriteLine("After discount the price is: {0}", i.Price);
                }


            }
            if (t == false)
            {
                Console.WriteLine("Invalid item code");
            }
        }
    }
    class invoice:InvoicedItem
    {
        public string ProductCode;
        public int Quantity;
        public float Amount;
        InvoicedItem a = new InvoicedItem();
        Item i = new Item();
        public void GenerateBill()
        {
            Console.WriteLine("Enter the item code");
            int c = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("The itemcode of the product is:", a.Itemcode);
            Console.WriteLine("The price of the product is:", a.Price);
            Console.WriteLine("The price of the product after discount is:", a.Price);

            
        }
    }

    class exceptionitemcode : ApplicationException
    {

        public string Message
        {
            get
            {
                return "itemcode is not matched";
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Item i = new Item();
            InvoicedItem a = new InvoicedItem();
           
            invoice d = new invoice();

            a:Console.WriteLine("choose your preferred option \n1.Add new item \n2.Remove an item \n3.Calculate discount \n4.generate a bill \n5.to get the weight\n6.exit");
            int ch = Convert.ToInt16(Console.ReadLine());
            switch (ch)
            {
                case 1:
                    a.AddItem();
                    goto a;
                case 2:
                    a.RemoveItem();
                    goto a;
                case 3:
                    a.calculatediscount();
                    goto a;
                case 4:
                    d.GenerateBill();
                    goto a;
                case 5:
                    i.convert();
                    goto a;
                case 6:
                    break;
                default:
                    Console.WriteLine("invalid choice");
                    goto a;


            }
            try
            {
                if (i.Itemcode != Convert.ToInt32(i.ProductCode))

                    throw (new exceptionitemcode());
            }
            catch (exceptionitemcode e)
            {
                Console.WriteLine(e.Message);
            }
        }

    }
}
