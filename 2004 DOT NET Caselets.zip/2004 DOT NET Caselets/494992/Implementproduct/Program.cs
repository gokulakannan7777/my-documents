﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ImplementProduct
{
    interface IProduct
    {
        int GetProductCode(string PName);
        string GetProductDesc(int pcode);
        int GetCategoryCode(int pcode);
        double GetDiscountPercent(int pcode);
        double GetQuantityOnSale();

    }
    class Product
    {
        private int productCode;
        public int ProductCode
        {
            get { return productCode; }
            set { productCode = value; }
        }
        public string ProductName { get; set; }
        public int CategoryCode { get; set; }
        public static int ProductCount = 0;
        //List<Product> pi = new List<Product>();
        //public ProductOnSale()
        //{
        //    Console.WriteLine("enter Product Name");
        //    ProductName = Console.ReadLine();
        //}
        public void AddProduct(List<Product> p)
        {
            Console.WriteLine("enter Product Name");
            StringBuilder MyStringBuilder = new StringBuilder(ProductName);
            ProductName = Console.ReadLine();
            Console.WriteLine("Enter Product Code");
            ProductCode = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Product Category Code");
            CategoryCode = Convert.ToInt32(Console.ReadLine());
            ProductCount += 1;


            Console.WriteLine("\n *******************\n   Entered Successfully   \n*******************");
            p.Add(new Product() { ProductCode = ProductCode, ProductName = ProductName, CategoryCode = CategoryCode });

        }

        public void RemoveProduct(Product p)
        {
            try
            {
                if (ProductCount <= 0)
                {
                    throw new UnderflowException();
                }
                else
                {
                    p.CategoryCode = 0;
                    p.ProductCode = 0;
                    p.ProductName = null;
                    ProductCount -= 1;
                    Console.WriteLine("The product isRemoved ");
                }
            }

            catch (UnderflowException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        public virtual void ModifyProduct(int pcode)
        {
            try
            {
                if (ProductCount <= 0)
                {
                    throw new UnderflowException();

                }
                else
                {
                    int a;
                    Console.WriteLine("Press\n1.To Change Name of Product\n2.To change Product code\n3.To change Category Code\n4.To Change all\n5.To Exit without Changing");
                    a = Convert.ToInt16(Console.ReadLine());
                    switch (a)
                    {
                        case 1: Console.WriteLine("enter new product name");
                            ProductName = Console.ReadLine();
                            break;
                        case 2: Console.WriteLine("enter new Product Code");
                            ProductCode = Convert.ToInt32(Console.ReadLine());
                            break;
                        case 3: Console.WriteLine("enter new Category Code");
                            CategoryCode = Convert.ToInt32(Console.ReadLine());
                            break;
                        case 4: Console.WriteLine("enter new ProductName\nProduct Code\nCategory Code");
                            ProductName = Console.ReadLine();
                            ProductCode = Convert.ToInt32(Console.ReadLine());

                            CategoryCode = Convert.ToInt32(Console.ReadLine());
                            break;
                        case 5: Console.WriteLine("exiting . .. .. .. ..");
                            break;

                    }
                    Console.WriteLine("The modified details of product is:");
                    Console.WriteLine(ToString());
                }
            }

            catch (UnderflowException ex)
            {
                Console.WriteLine(ex.Message);

            }

        }



        public override string ToString()
        {
            return "ProductCode :" + "" + productCode + "," + "\n" + " ProductName:" + "" + ProductName + "," + "\n" + "CategoryCode:" + "" + CategoryCode;
        }
    }
    class ProductOnDiscount : Product, IProduct
    {
        public double DiscountPercentage { get; set; }
        public int MinimumPickQuantity { get; set; }
        List<Product> p = new List<Product>();
        List<ProductOnDiscount> pd = new List<ProductOnDiscount>();

        public void AddProduct()
        {
            Console.WriteLine("enter Product Name");
            StringBuilder MyStringBuilder = new StringBuilder(ProductName);
            ProductName = Console.ReadLine();
            Console.WriteLine("Enter Product Code");
            ProductCode = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Product Category Code");
            CategoryCode = Convert.ToInt32(Console.ReadLine());
            ProductCount += 1;

        }
        public void CopyAProduct(int pcode)
        {
            //int a;
            //Console.WriteLine("Enter the Productcode of project you want to move");
            //a = Convert.ToInt16(Console.ReadLine());
            //pd.AddRange(p.GetRange(0, a));
            //List<ProductOnDiscount> pd = p.GetRange(0, a);
            // var selected = from p in Product

            //                where p.Productcode>0   
            //                select p;

            ////pd.AddRange(selected);
            //var selected = p.Where(Product => Product.ProductCount > 10).ToList();
            //p = p.Except(selected).ToList();
            //pd.AddRange(p.GetRange(selected));




        }
        public override void ModifyProduct(int pcode)
        {
            ProductOnSale p = new ProductOnSale();
            if (p.ProductCode == pcode)
            {
                int a;
                Console.WriteLine("Press\n1.To Change Name of Product\n2.To change Product code\n3.To change Category Code\n4.To Change all\n5.To Exit without Changing");
                a = Convert.ToInt16(Console.ReadLine());
                switch (a)
                {
                    case 1:
                        Console.WriteLine("enter new product name");
                        ProductName = Console.ReadLine();
                        break;
                    case 2:
                        Console.WriteLine("enter new Product Code");
                        ProductCode = Convert.ToInt32(Console.ReadLine());
                        break;
                    case 3:
                        Console.WriteLine("enter new Category Code");
                        CategoryCode = Convert.ToInt32(Console.ReadLine());
                        break;
                    case 4:
                        Console.WriteLine("enter new ProductName\nProduct Code\nCategory Code");
                        ProductName = Console.ReadLine();
                        ProductCode = Convert.ToInt32(Console.ReadLine());
                        CategoryCode = Convert.ToInt32(Console.ReadLine());
                        break;
                    case 5:
                        Console.WriteLine("exiting . .. .. .. ..");
                        break;
                }
            }
        }
        public void ModifyProduct(string pName)
        {
            ProductOnSale p = new ProductOnSale();
            if (p.ProductName.Equals(pName))
            {
                int a;
                Console.WriteLine("Press\n1.To Change Name of Product\n2.To change Product code\n3.To change Category Code\n4.To Change all\n5.To Exit without Changing");
                a = Convert.ToInt16(Console.ReadLine());
                switch (a)
                {
                    case 1:
                        Console.WriteLine("enter new product name");
                        p.ProductName = Console.ReadLine();
                        break;
                    case 2:
                        Console.WriteLine("enter new Product Code");
                        p.ProductCode = Convert.ToInt32(Console.ReadLine());
                        break;
                    case 3:
                        Console.WriteLine("enter new Category Code");
                        p.CategoryCode = Convert.ToInt32(Console.ReadLine());
                        break;
                    case 4:
                        Console.WriteLine("enter new ProductName\nProduct Code\nCategory Code");
                        ProductName = Console.ReadLine();
                        ProductCode = Convert.ToInt32(Console.ReadLine());
                        CategoryCode = Convert.ToInt32(Console.ReadLine());
                        break;
                    case 5:
                        Console.WriteLine("exiting . .. .. .. ..");
                        break;
                }
            }
        }
        public void RemoveProduct(int pcode)
        {

        }
        public void RemoveProduct(string pname, int pcode)
        {

        }
        public int GetProductCode(string PName)
        {
            int pcode = 0;
            return pcode;
        }
        //public List<string> GetAllProductCodes()
        //{

        //    string pname=" ";
        //    return 
        //}
        public double GetDiscountPercent(int pcode)
        {
            double perc = 1.0;

            Console.WriteLine("Discount Percent is:{0}", perc);
            return perc;
        }
        public string GetProductDesc(int pcode)
        {
            string pname = "";
            return pname;
        }
        public int GetCategoryCode(int pcode)
        {
            int Ccode = 0;
            return Ccode;
        }
        public double GetQuantityOnSale()
        {
            double d = 10.00;
            return d;
        }
        public override string ToString()
        {
            return ProductCode + "\n" + ProductName + "\n" + CategoryCode;
        }
    }
    class ProductOnSale : Product, IProduct
    {
        public int QuantityOnSale { get; set; }
        public List<int> BatchID = new List<int>();
        public ProductOnSale()
        {
            Console.WriteLine("enter Product Id");
            ProductCode = Convert.ToInt32(Console.ReadLine());
        }
        public void AddProduct(int pcode)
        {
            int b;
            //if (BatchID == null)
            //{
            Console.WriteLine("enter new batch id");
            b = Convert.ToInt32(Console.ReadLine());
            BatchID.Add(b);
            ProductCode = pcode;
            QuantityOnSale += 1;
            //}
            //else
            //{
            //    Console.WriteLine("enter batchid");
            //}
        }
        public void AddProduct(string pname, int pcode)
        {

        }
        public void RemoveProduct(int pcode)
        {
            ProductOnSale p = new ProductOnSale();
            if (p.ProductCode == pcode)
            {
                p.CategoryCode = 0;
                p.ProductCode = 0;
                p.ProductName = null;
                ProductCount -= 1;
            }
        }
        //public void RemoveProduct(int pcode, string pname)
        //{
        //    ProductOnSale p = new ProductOnSale();
        //    if (p.ProductCode == pcode)
        //    {
        //        p.CategoryCode = 0;
        //        p.ProductCode = 0;
        //        p.ProductName = null;
        //        ProductCount -= 1;
        //    }
        //}
        public double GetQuantityOnSale()
        {
            Console.WriteLine("The Quantity on Sale is:{0}", ProductCount);
            return QuantityOnSale;
        }
        public string GetProductDesc(int pcode)
        {
            ProductOnSale p = new ProductOnSale();
            if (p.ProductCode == pcode)
            {
                return (p.ProductCode + "\n" + p.ProductName + "\n" + p.CategoryCode).ToString();
            }
            else
                return "no match is found";
        }
        public int GetCategoryCode(int pcode)
        {
            ProductOnSale p = new ProductOnSale();
            if (p.ProductCode == pcode)
            {
                return p.CategoryCode;
            }
            else
                return 0;
        }
        public int GetProductCode(string pname)
        {
            ProductOnSale p = new ProductOnSale();
            if (p.ProductName.Equals(pname))
            {
                return p.ProductCode;
            }
            else
                return 0;
        }
        public double GetDiscountPercent(int pcode)
        {
            double perc = 1.0;
            return perc;
        }
        public override string ToString()
        {
            return BatchID + "\n" + ProductCode + "\n" + ProductName + "\n" + CategoryCode;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<Product> p = new List<Product>();
            Product p1 = new Product();
            ProductOnDiscount p2 = new ProductOnDiscount();
            ProductOnSale p3 = new ProductOnSale();
            List<ProductOnSale> ps = new List<ProductOnSale>();
            List<ProductOnDiscount> pd = new List<ProductOnDiscount>();
            //var Product = new List<String>();


            //Console.WriteLine("Select any one of the follwoing:");
            //Console.WriteLine(" 1) Add Product 2) Remove Product 3)Modify Product 4)Copy a Product 5)Exit");
            int op, ch;

            do
            {
                Console.WriteLine("Select any one of the follwoing:");
            u:Console.WriteLine(" 1) Add Product\n 2) Remove Product\n 3)Modify Product \n4)To know Discount of the product \n 5) To know product in Sale\n  6) Display  List Elements \n  7)Exit");

                op = Convert.ToInt32(Console.ReadLine());

                switch (op)
                {
                    case 1: p1.AddProduct(p);
                        goto u; 
                          
                    case 2:

                        p1.RemoveProduct(p1);
                        Console.WriteLine(p1.ToString());

                        break;
                    case 3:

                        Console.WriteLine("Press\n1.To Change Name of Product\n2.To change Product code\n3.To change Category Code\n4.To Exit without Changing");
                        Console.WriteLine("Enter your choice");
                        Console.WriteLine("Enter Product Code");
                        int a;
                        a = Convert.ToInt32(Console.ReadLine());

                        p1.ModifyProduct(a);
                        Console.WriteLine("The modified details of product is:");
                        Console.WriteLine(p1.ToString());
                        break;

                    case 4: int a1;
                        Console.WriteLine("Enter the productcode  of the product");
                        a1 = Convert.ToInt32(Console.ReadLine());

                        p2.GetDiscountPercent(a1);
                        //p2.AddProduct();
                        break;
                    case 5: int a2;
                        Console.WriteLine("Enter the productcode  of the product");
                        a2 = Convert.ToInt32(Console.ReadLine());
                        p3.AddProduct(a2);
                        p3.GetQuantityOnSale();
                        break;
                    case 6:
                        Console.WriteLine("Sorted List is:");
                        //p.Sort();
                        foreach (Product i in p)
                        {
                            Console.WriteLine(i);
                        }
                        //p.Sort();
                        break;


                    case 7: Console.WriteLine("Exiting.....");
                        break;
                    default: Console.WriteLine("Invalid Option");
                        break;

                }
                Console.WriteLine("Do you want to continue(y/n)?:");
                ch = Convert.ToChar(Console.ReadLine());
            } while (ch == 'Y' || ch == 'y');


            p.Sort();

            Console.WriteLine("Sorted List is:");

        }

    }
    class UnderflowException : ApplicationException
    {
        public override string Message
        {
            get
            {
                return "UnderFlowException \n No Data Found";
            }
        }
    }
}
