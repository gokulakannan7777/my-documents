﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _476024_SW_Tech
{public class Department
    {
       int? dept_id;
       string dep_name;
       static int CountOfEmployees = 0;

        public int? dept_Id
        {
            get
            {
                return dept_id;
            }
            set {
                dept_id = value;
            }
        }
        public string dept_name
        {
            get
            {
                return dep_name;
            }
            set
            {
                dep_name = value;
            }
        }
        public Department()
        {
            CountOfEmployees++;
        }
    }

    class Employee : Department
    {
        private string empl_name;
        private int empl_Id;
        private double empl_salary;
        private string empl_designation;
        private int manag_Id;
        private int dept;

        public string emp_name
        {
            get
            {
                return empl_name;
            }
            set
            {
                empl_name = value;
            }
        }
        public int emp_Id
        {
            get
            {
                return empl_Id;
            }
            set
            {
                empl_Id = value;
            }
        }
        public double emp_salary
        {
            get
            {
                return empl_salary;
            }
            set
            {
                empl_salary = value;
            }
        }
        public string emp_designation
        {
            get
            {
                return empl_designation;
            }
            set
            {
                empl_designation = value;
            }
        }
        public int manager_Id
        {
            get
            {
                return manag_Id;
            }
            set
            {
                manag_Id = value;
            }
        }

        public Employee()
        {
        }

        public Employee(int id, String name)
        {
        }

        public Employee(int dept)
        {
            this.dept = dept;
        }


        public void Add_Employee(List<Employee> employeeList)
        {
            Console.WriteLine("Enter Employee Name");
            emp_name = Console.ReadLine();
            while (true)
            {
                try
                {
                    Console.WriteLine("Enter Employee ID");
                    emp_Id = Convert.ToInt16(Console.ReadLine());
                    break;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message + "\n Please Enter Valid Data \n");
                }
            }
            while (true)
            {
                try
                {
                    Console.WriteLine("Enter Salary");
                    emp_salary = Convert.ToInt32(Console.ReadLine());
                    break;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message + "\n Salary Should Be In Numerics\n");
                }
            }

            Console.WriteLine("Enter Employee Designation");

            emp_designation = Console.ReadLine();
           
            if (dept == 1)
            {
                dept_name = "HR";
                dept_Id = 1;
                manager_Id = 10;
            }
            else if (dept == 2)
            {
                dept_name = "Accounts";
                dept_Id = 2;
                manager_Id = 20;
            }
            else if (dept == 3)
            {
                dept_name = "Development";
                dept_Id = 3;
                manager_Id = 30;
            }
            int count = 0;
            foreach (Employee le in employeeList)
            {
                if (le.dept_Id == dept)
                {
                    count++;
                }
            }
            try
            {
                if (count < 5)
                {
                    employeeList.Add(new Employee() { emp_name = empl_name, emp_Id = empl_Id, emp_salary = empl_salary, emp_designation = empl_designation, dept_Id = dept, manager_Id = manag_Id, dept_name = dept_name });
                    StringBuilder sb1 = new StringBuilder("Entered successfully");
                    Console.WriteLine(sb1);
                }

                else
                {
                    Console.WriteLine("\n Employee count exceeds in the respective Department\n");
                    throw new UserDefinedExceptions();
                }
            }
            catch (UserDefinedExceptions)
            {

            }

        }

        public void Delete_Employee(List<Employee> employeeList)
        {
            try
            {
                Console.WriteLine("\n Enter Employee ID");
                int id = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine("Enter Department ID");
                int did = Convert.ToInt16(Console.ReadLine());
                int p = 0, flag = 0;

                foreach (Employee le in employeeList)
                {
                    if (le.emp_Id == id && le.dept_Id == did)
                    {
                        employeeList.RemoveAt(p);
                        flag = 1;
                        break;
                    }
                    p++;

                }
                if (flag == 1)
                {
                    StringBuilder sb2 = new StringBuilder("Deleted successfully");
                    Console.WriteLine(sb2);
                }
                else
                {
                    Console.WriteLine("No valid Employee in the Department");
                }
            }
            catch (UserDefinedExceptions e)
            {
                e = new UserDefinedExceptions();
            }

        }
        public override string ToString()
        {
            return "EMPLOYEE NAME:\t" + emp_name + "\nEMPLOYEE ID:\t" + emp_Id + "\nEMPLOYEE  SALARY:\t" + DeductIncomeTax(emp_salary) + "\nEMPLOYEE DESIGNATION:\t" + emp_designation + "\nMANAGER ID:\t" + manager_Id + "\nDEPARTMENT ID:\t" + dept_Id + "\nDEPARTMENT NAME:\t" + dept_name;
        }

        public void Display_All_Employees(List<Employee> employeeList)
        {

            foreach (Employee le in employeeList)
            {
                Console.WriteLine(le);
            }
        }

        public void Modify_Salary(List<Employee> employeeList)
        {
            Console.WriteLine(" Enter Employee ID");
            int id = Convert.ToInt16(Console.ReadLine());

            Console.WriteLine("Enter Department ID");
            int did = Convert.ToInt16(Console.ReadLine());

            Console.WriteLine("Enter New Salary ");
            int sal = Convert.ToInt32(Console.ReadLine());

            int s = 0;

            foreach (Employee le in employeeList)
            {
                if (le.emp_Id == id && le.dept_Id == did)
                {
                    le.emp_salary = sal;
                    s = 1;
                }
            }
            if (s == 1)
            {
                StringBuilder sb3 = new StringBuilder("Salary is updated");
                Console.WriteLine(sb3);
            }
            else
            {
                Console.WriteLine(" Please Enter Valid Details");
            }
        }

        public void Modify_Designation(List<Employee> employeeList)
        {
            Console.WriteLine("Enter Employee ID");
            int id = Convert.ToInt16(Console.ReadLine());

            Console.WriteLine("Enter Department ID");
            int did = Convert.ToInt16(Console.ReadLine());

            Console.WriteLine("Enter New Designation ");
            string des = Console.ReadLine();

            int h = 0;

            foreach (Employee le in employeeList)
            {
                if (le.emp_Id == id && le.dept_Id == did)
                {
                    le.emp_designation = des;
                    h = 1;
                }
            }
            if (h == 1)
            {
                StringBuilder sb4 = new StringBuilder("Designation is modified");
                Console.WriteLine(sb4);
            }
            else
            {
                Console.WriteLine("Please Enter Valid Details");
            }
        }
        public void Find_RM(List<Employee> employeeList)
        {
            Console.WriteLine("Enter Employee ID:");
            int id = Convert.ToInt32(Console.ReadLine());
            int flag = 0;
            foreach (Employee le in employeeList)
            {
                if (le.emp_Id == id)
                {
                    if (le.dept_Id == 1)
                    {
                        Console.WriteLine("Your Manager is ONE");
                        flag = 1;
                    }
                    else if (dept == 2)
                    {
                        Console.WriteLine("Your Manager is TWO");
                        flag = 1;
                    }
                    else if (dept == 3)
                    {
                        Console.WriteLine("Your Manager is THREE");
                        flag = 1;
                    }
                }
            }
            if (flag == 0)
            {
                Console.WriteLine("Please Enter Valid Employee ID");
            }

        }

        public void Transfer_Employee(List<Employee> employeeList)
        {
            int count = 0;
            string deptName = "";
            Console.WriteLine("Enter the Department ID of the Employee:");
            int did = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Department ID to which the Employee has to be transfered");
            int nid = Convert.ToInt32(Console.ReadLine());


            if (did == 1 || did == 2 || did == 3)
            {
                if (nid == 1 || nid == 2 || nid == 3)
                {
                    if (nid == 1)
                    { dept_name = "HR"; }
                    else if (nid == 2)
                    { dept_name = "Accounts"; }
                    else if (nid == 3)
                    { dept_name = "Development"; }
                }

                    foreach (Employee le in employeeList)
                    {
                        if (le.dept_Id == nid)
                        {
                            count++;
                        }
                    }
                    if (count >= 5)
                    {
                        Console.WriteLine("You cannot transfer the Employee to the Department {0}", deptName);
                    }
                    else
                    {
                        Console.WriteLine("Enter the Employee ID");
                        int id = Convert.ToInt32(Console.ReadLine());
                        int flag = 0;
                        foreach (Employee le in employeeList)
                        {
                            if (le.emp_Id == id)
                            {
                                le.dept_Id = nid;
                                le.dept_name = deptName;
                                flag = 1;
                            }
                        }
                        if (flag == 1)
                        {
                            Console.WriteLine("Employee is transfered successfully");
                        }
                        else
                        {
                            Console.WriteLine("Please Enter valid Employee ID");
                        }
                    }
                }
                else Console.WriteLine("Department ID is incorrect");
            }
        public double DeductIncomeTax(double sal)
        {
            double d = ((4.5) * sal) / 100;
            return sal-d;
        }
    }
    interface IIncomeTAx
    {
        double DeductIncomeTax(double sal);
    }
    class UserDefinedExceptions : ApplicationException
    {
        public UserDefinedExceptions()
            : base("Please Enter Valid Input")
        {
            Console.WriteLine("Please Enter Valid Input");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> employeeList = new List<Employee>();


            int choice = 0;
            int dept;
            Console.WriteLine("Welcome to SW-TECH Software Services");

            while (true)
            {
                while (true)
                {

                    Console.WriteLine("\nPlease Select The Department:\n \n1.HR\t2.Accounts\t3.Developments\n");
                    dept = Convert.ToInt32(Console.ReadLine());
                    break;

                }

                if (dept == 1 || dept == 2 || dept == 3)
                {
                    do
                    {
                        try
                        {
                            Console.WriteLine("Enter Your Choice :\n \n1.Add Employee\n2.Delete Employee\n3.Display Employee Details\n4.Modify Salary\n5.Modify Designation\n6.Find RM\n7.Transfer Employee\n");
                            choice = Convert.ToInt32(Console.ReadLine());
                        }
                        catch (Exception ed)
                        {
                            Console.WriteLine(ed.Message + "\n Please choose from the choice given \n");
                        }
                        Employee e = new Employee(dept);
                        switch (choice)
                        {
                            case 1:
                                e.Add_Employee(employeeList);
                                break;
                            case 2:
                                e.Delete_Employee(employeeList);
                                break;
                            case 3:
                                e.Display_All_Employees(employeeList);
                                break;
                            case 4:
                                e.Modify_Salary(employeeList);
                                break;
                            case 5:
                                e.Modify_Designation(employeeList);
                                break;
                            case 6:
                                e.Find_RM(employeeList);
                                break;
                            case 7:
                                e.Transfer_Employee(employeeList);
                                break;
                            default: Console.WriteLine("Enter valid choice");
                                break;
                        }
                    } while (choice < 8);
                }
                else
                {
                    Console.WriteLine("Please Enter Valid Input");
                }
            }
        }
    }
}
