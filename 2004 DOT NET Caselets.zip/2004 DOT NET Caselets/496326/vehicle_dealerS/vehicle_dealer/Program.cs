﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vehicle_dealer
{
    class Program
    {
        static void Main(string[] args)
        {
            Model obj = new Model();
            List<Model> modelList = new List<Model>();
           
            while (true)
            {
                Console.WriteLine("\tWelcome to TEST- World of Four Wheeler Vehicles !!!\n");
                Console.WriteLine("\t*****************************************\n");
                Console.WriteLine("\t Choose Your Choice:\n \t1.Add Model\n \t2.Delete Model\n \t3.Display All Models\n \t4.Modify Price\n \t5.Lowest Priced Model\n \t6.Models In A given price Range\n \t7.Display1 Model\n \t8.Check if a Model is Available\n \t9.Calculate VAT\n\t10.Exit\n");
                Console.WriteLine("\nEnter your choice");
                int ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)
                {
                    case 1:
                        obj.addModel(modelList);
                        break;
                    case 2:
                        obj.deleteModel(modelList);
                        break;
                    case 3:
                        obj.displayallModels(modelList);
                        break;
                    case 4:
                        obj.modifyPrice(modelList);
                        break;
                    case 5:
                        obj.lowestPricedModel(modelList);
                        break;
                    case 6:
                        obj.modelsInAPriceRange(modelList);
                        break;
                    case 7:
                        obj.display1model(modelList);
                        break;

                    case 8:
                        obj.checkAvailable(modelList);
                        break;
                    case 9:
                        obj.IcalculateVAT();
                        break;
                    case 10:
                         //obj.exit();
                        Environment.Exit(0);
                        break;
                    default: Console.WriteLine("Please enter valid choice");
                        break;

                }
            }
        }
    }
}
    

