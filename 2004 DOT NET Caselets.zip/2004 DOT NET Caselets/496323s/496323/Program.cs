﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _496323_CHAIR
{

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("<----Moving chair Movement------>");
            Console.WriteLine("Enter the Item code");
            int itmcde = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Enter the Weight of the Chair");
            string weigth = Console.ReadLine();
            Console.WriteLine("Enter the Material of The Chair");
            string material = Console.ReadLine();
            Console.WriteLine("Enter the Chair Price");
            int itmprice = Convert.ToInt16(Console.ReadLine());

            rotating_chair rotatingchair = new rotating_chair(itmcde, weigth, material, itmprice);

            while (true)
            {
                Console.WriteLine("enter Selection---> A.Move , B .Exit ");
                string k = Console.ReadLine();
                int xpos, ypos = 0;
                if (k == "A")
                {
                    Console.WriteLine("Enter Position of X--->");
                    xpos = Convert.ToInt16(Console.ReadLine());
                    Console.WriteLine("Enter Position of Y-->");
                    ypos = Convert.ToInt16(Console.ReadLine());

                }
                else
                {
                    break;
                }
                int rotation;
                Console.WriteLine("enter the rotation angle");
                rotation = Convert.ToInt16(Console.ReadLine());

                try
                {
                    if (rotation > 60)
                    {
                        throw (new rotationexception());
                    }

                }
                catch (rotationexception i)
                {

                    Console.WriteLine(i.message);
                }
            }
        }









    }
}



