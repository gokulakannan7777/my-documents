﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flight
{
    sealed class commercialflight : flight, iflight
    {
        public static int flightnumber = 1000;
        public commercialflight()
        {

        }
       
        public commercialflight(string type, int flightnum, int availableSeats, string source, string destination, float speed, int distance, DateTime time)
        {
            this.FlightNo = flightnum;
            this.Type = type;
            AvailableSeats = availableSeats;
            Source = source;
            Destination = destination;
            Speed = speed;
            Distance = distance;
            StartTime = time;
        }
        private int availableseats;
        private string source;
        private string destination;
        public int AvailableSeats
        {
            get { return availableseats; }
            set { availableseats = value; }
        }
        public string Destination
        {
            get { return destination; }
            set { destination = value; }
        }
        public string Source
        {
            get { return source; }
            set { source = value; }
        }
        public override string ToString()
        {
            return "flight types:" + Type + "\n flight number:" + FlightNo + "\n Available Seats:" + AvailableSeats + "\nSource:" + Source + "\nDestination:" + Destination + "\nStart Time:" + StartTime + "\nDistance in kms:" + Distance;
        }
        List<commercialflight> commflight = new List<commercialflight>();
        public override void AddFlight(string flighttype)
        {
            try
            {
                Console.WriteLine("Enter Seating Capacity");
                int available = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the distance in kms");

                int distance = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Speed in kmph");

                float speed = Convert.ToSingle(Console.ReadLine());
                Console.WriteLine("Source");

                string source = Console.ReadLine();
                if (!IsAllLetters(source))
                    throw new InvalidDetailsException();
                Console.WriteLine("Destination  ");

                string destination = Console.ReadLine();
                if (!IsAllLetters(destination))
                    throw new InvalidDetailsException();

                Console.WriteLine("enter start time");
                DateTime time = Convert.ToDateTime(Console.ReadLine());
                commercialflight cmf = new commercialflight(flighttype, flightnumber++, available, source, destination, speed, distance, time);
                commflight.Add(cmf);
                Console.WriteLine("\n flight details added successfully");
                Console.WriteLine(cmf);
            }
            catch (InvalidDetailsException a)
            {
                Console.WriteLine(a.Message);
            }
            catch (Exception a)
            {
                Console.WriteLine(a.Message);
            }
        }
        public override void RemoveFlight()
        {
            try
            {
                Console.WriteLine("Enter the flight number-");
                int flightno = Convert.ToInt32(Console.ReadLine());
                int count = 0;
                int index = 0;
                foreach (commercialflight comf in commflight)
                {
                    if (comf.FlightNo == flightno)
                    {
                        commflight.RemoveAt(index);
                        Console.WriteLine("flight removed");
                        count++;
                        break;
                    }
                    index++;
                }
                if (count == 0)
                {
                    Console.WriteLine("flight not found");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public override void CalculateDuration()
        {
            try
            {
                int count = 0;
                Console.WriteLine("enter flight Number-");
                int fn = Convert.ToInt32(Console.ReadLine());
                foreach (commercialflight comf in commflight)
                {
                    if (comf.FlightNo == fn)
                    {
                        float duration = (comf.Distance / comf.Speed) * 60;
                        Console.WriteLine(duration + " mins");
                        count++;
                        break;
                    }
                }
                if (count == 0)
                {
                    Console.WriteLine("flight is not found");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void GetFlightDetails()
        {
            try
            {
                int count = 0;
                Console.WriteLine("enter flight number-");
                int fn = Convert.ToInt32(Console.ReadLine());
                foreach (commercialflight comf in commflight)
                {
                    if (comf.FlightNo == fn)
                    {
                        Console.WriteLine(comf);
                        count++;
                        break;
                    }
                }
                if (count == 0)
                {
                    Console.WriteLine("Flight not found");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void GetSource()
        {
            try
            {
                int count = 0;
                Console.WriteLine("Enter Flight Number ");
                int fn = Convert.ToInt32(Console.ReadLine());
                foreach (commercialflight comf in commflight)
                {
                    if (comf.FlightNo == fn)
                    {
                        Console.WriteLine(comf.Source);
                        count++;
                        break;
                    }
                }
                if (count == 0)
                {
                    Console.WriteLine("Flight not found");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }


        public void GetDuration()
        {
            try
            {
                int count = 0;
                Console.WriteLine("Enter Flight Number ");
                int fn = Convert.ToInt32(Console.ReadLine());
                foreach (commercialflight comf in commflight)
                {
                    if (comf.FlightNo == fn)
                    {
                        float duration = (comf.Distance / comf.Speed) * 60;
                        Console.WriteLine(duration + " mins");
                        count++;
                        break;
                    }
                }
                if (count == 0)
                {
                    Console.WriteLine("flight is not found");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public void GetDestination()
        {
            try
            {
                int count = 0;
                Console.WriteLine("Enter the Flight Number ");
                int fn = Convert.ToInt32(Console.ReadLine());
                foreach (commercialflight comf in commflight)
                {
                    if (comf.FlightNo == fn)
                    {
                        Console.WriteLine("destination=" + comf.Destination);
                        count++;
                        break;
                    }
                }
                if (count == 0)
                {
                    Console.WriteLine("Flight not found");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void GetStartTime()
        {
            try
            {
                int count = 0;
                Console.WriteLine("Enter Flight Number ");
                int fn = Convert.ToInt32(Console.ReadLine());
                foreach (commercialflight comf in commflight)
                {
                    if (comf.FlightNo == fn)
                    {
                        Console.WriteLine("start time=" + comf.StartTime);
                        count++;
                        break;
                    }
                }
                if (count == 0)
                {
                    Console.WriteLine("Flight not found");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void GetAvailability(int NoOfSeats)
        {
            try
            {
                int count = 0;
                Console.WriteLine("Enter the Flight Number ");
                int fn = Convert.ToInt32(Console.ReadLine());
                foreach (commercialflight comf in commflight)
                {
                    if (comf.FlightNo == fn)
                    {
                        if (comf.AvailableSeats >= NoOfSeats)
                        {
                            Console.WriteLine("Available");
                            count++;
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Unavailable");
                            count++;
                            break;
                        }
                    }
                }
                if (count == 0)
                {
                    Console.WriteLine("Flight not found");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void listofavailableflights()
        {
            try
            {
                int count = 0;
                Console.WriteLine("Enter the Source Location ");
                string src = Console.ReadLine();

                Console.WriteLine("Enter the Destination-");
                string dest = Console.ReadLine();
                if (src == dest)
                    throw new SameSourceAndDestinationException();
                else
                {
                    foreach (commercialflight comf in commflight)
                    {
                        if (comf.Source == src && comf.Destination == dest)
                        {
                            Console.WriteLine("Flight Number:" + comf.FlightNo + "   Start Time:" + comf.StartTime);
                            count++;
                        }
                    }
                    if (count == 0)
                    {
                        Console.WriteLine("No flights available between " + src + " and " + dest + "..!!");
                    }
                }
            }
            catch (SameSourceAndDestinationException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}