﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flight
{
    interface iflight
    {
        void GetFlightDetails();
        void GetSource();
        void GetDestination();
        void GetStartTime();
        void GetDuration();
        void GetAvailability(int NoOfSeats);
    }
}
