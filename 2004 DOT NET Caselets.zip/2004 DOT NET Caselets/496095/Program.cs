﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flight
{
    class Program
    {
        static void Main(string[] args)
        {

            commercialflight comfl = new commercialflight();
            charterflight corfl = new charterflight();
            int boundary = 0;

            while (boundary == 0)
            {
                int choice = 3;
                Console.WriteLine("\n------flight class implemention------");
                Console.WriteLine("Choose the type of flight \n(1.) Commercial Flight  \n(2.) Charterflight \n(3.)Exit");
                try
                {
                    choice = Convert.ToInt32(Console.ReadLine());
                }
                catch (Exception)
                {
                    Console.WriteLine("invalid Choice");
                }

                switch (choice)
                {
                    case 1:

                        Console.WriteLine("\nChoose \n(1.) Add Flight \n(2.) Remove Flight \n(3.) Calculate Duration \n(4.) Get Flight Details \n(5.) Get Source \n(6.) Get Destination \n(7.) Get Start Time \n(8.) GetDuration \n(9.) Get Availability \n(10.) List of available flights \n(11.) Go back");
                        int ch = 0;
                        try
                        {
                            ch = Convert.ToInt32(Console.ReadLine());
                        }
                        catch (Exception)
                        {
                            Console.WriteLine("invalid Choice");
                        }
                        switch (ch)
                        {
                            case 1:
                                string flighttype = "commercial";

                                comfl.AddFlight(flighttype);
                                break;

                            case 2: comfl.RemoveFlight();
                                break;

                            case 3: comfl.CalculateDuration();
                                break;

                            case 4: comfl.GetFlightDetails();
                                break;

                            case 5: comfl.GetSource();
                                break;

                            case 6: comfl.GetDestination();
                                break;
                            case 7: comfl.GetStartTime();
                                break;

                            case 8: comfl.GetDuration();
                                break;

                            case 9:
                                Console.WriteLine("enter required Number of seats ");
                                int a = Convert.ToInt32(Console.ReadLine());
                                comfl.GetAvailability(a);
                                break;

                            case 10:
                                comfl.listofavailableflights();
                                break;

                            case 11:
                                break;

                            default: Console.WriteLine("incorrect Option");
                                break;
                        }
                        break;
                    case 2:
                        Console.WriteLine("Choose \n(1.) Add Flight \n(2.) Remove Flight \n(3.) Calculate Duration \n (4.)Get Flight Details \n(5.) Go back");
                        int g = 0;
                        try
                        {
                            g = Convert.ToInt32(Console.ReadLine());
                        }
                        catch (Exception)
                        {
                            Console.WriteLine("entered invalid choice ");
                        }
                        switch (g)
                        {
                            case 1:
                                string flighttype = "charter ";
                                corfl.AddFlight(flighttype);
                                break;

                            case 2: corfl.RemoveFlight();
                                break;

                            case 3: corfl.CalculateDuration();
                                break;

                            case 4: corfl.GetFlightDetails();
                                break;

                            case 5: break;
                            default: Console.WriteLine("Incorrect Option");
                                break;
                        }
                        break;
                    case 3: boundary = 1;
                        break;

                    default: Console.WriteLine("incorrect option");
                        break;
                }


            }
        }
    }
}

