﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flight
{
    class SameSourceAndDestinationException : ApplicationException
    {
        public SameSourceAndDestinationException()
            : base("Source and Destination entered are same")
        {
        }
    }
    class InvalidDetailsException : ApplicationException
    {
        public InvalidDetailsException()
            : base("Given Input is not valid")
        {
        }
    }

}





