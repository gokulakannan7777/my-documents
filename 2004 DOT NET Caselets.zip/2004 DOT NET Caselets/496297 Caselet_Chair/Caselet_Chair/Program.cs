﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Caselet_Chair
{
    class Program
    {
           
          
         static void Main(string[] args)
        {
          
            Console.WriteLine("***************Chair Movement***************");
            int noc = 0;
            
            Console.WriteLine("Enter the Chair code");
            int itemcode = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Enter the Weight of the Chair (in kg)");
            string weight = Console.ReadLine();
            Console.WriteLine("Enter the Material of The Chair");
            string material = Console.ReadLine();
            Console.WriteLine("Enter the Chair Price");
            int itmprice = Convert.ToInt16(Console.ReadLine());
            noc ++;
            Console.WriteLine("The number of chairs are:{0}",noc);
            
           

            rotating_chair rotatingchair = new rotating_chair(itemcode, weight, material, itmprice);

            while (true)
            {
                Console.WriteLine("\n Login as \n A. User \n B. Admin");
                string k = Console.ReadLine();
                int xpos, ypos = 0;  
                if (k == "A")
                {
                    Console.WriteLine("Select : \n 1. Move \n 2. Exit ");
                    string s = Console.ReadLine();
                    if (s == "1")
                    {
                        Console.WriteLine("Enter Position of X:");
                        xpos = Convert.ToInt16(Console.ReadLine());
                        Console.WriteLine("Enter Position of Y: ");
                        ypos = Convert.ToInt16(Console.ReadLine());
                        IChairUser cu = new wheel_chair();
                        cu.Move(xpos,ypos);
                    }
                    else
                    {
                        break;
                    }

                }
                else if (k == "B")
                {
                    Console.WriteLine("Select : \n 1. Rotate chair \n 2. Add Wheel \n 3. Remove Wheel \n");
                   string s = Convert.ToString(Console.ReadLine());
                    IChairAdmin ca = new wheel_chair();

                    switch(s)
                    {
                        case "1" :
                            int angle;
                            Console.WriteLine("Enter the rotation angle:");
                            angle = Convert.ToInt16(Console.ReadLine());
                            ca.RotateChair(angle);
                            break;
                        case "2" :
                            ca.AddWheel(4);
                            break;
                        case "3" :

                            Console.WriteLine("Enter the number of wheels you want to remove:");
                            w = Convert.ToInt16(Console.ReadLine());
                            ca.RemoveWheel(w);
                            break;                        
                    }

                }
                else
                {
                    break;
                }

               
            }
        }

         public static int w { get; set; }
    }
        }
    

