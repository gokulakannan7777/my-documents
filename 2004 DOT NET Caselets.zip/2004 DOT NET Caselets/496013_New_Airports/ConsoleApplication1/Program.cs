﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace New_Airports_496013
{
    public abstract class AirportEssentials
    {
        public string AirportName;
        public readonly long AirportID;
        public string CityName;
        public int AllotedAreaforAirport;
        public int AllotedAreaforParking;
        public string Address;

        public void AddNewAirport() { }
        public void RemoveAirport() { }
        public void EditAirportDetails() { }
        public void GetDetailsforNewAirport() { }
        public void showAirportDetails() { }
    }
    public class DomesticAirport : AirportEssentials
    {
        public int MinRequiredAirStripLength = 1850;
        public int minNoOfFlightsPerDay = 5, minflights;
        public int MaxNoOfFlightsPerDay = 50, maxflights;
        public int DistanceFromCity = 50;
        public int MinRequiredLand = 250;
        public int i = 0;
        public readonly long id = 2017123;
        public long num, aid, idno;

        List<DomesticAirport> list1 = new List<DomesticAirport>();

        public void AddNewAirport()
        {
            DomesticAirport d = new DomesticAirport();


        a: Console.WriteLine("Enter the Airport Name\n");
            d.AirportName = Console.ReadLine();
            Console.WriteLine("Enter the City Name\n");
            d.CityName = Console.ReadLine();
            Console.WriteLine("Enter Area Alloted for Airport in Acers\n");
            d.AllotedAreaforAirport = Convert.ToInt16(Console.ReadLine());
            if ((d.AllotedAreaforAirport) < MinRequiredLand)
            {
                try
                {
                    throw new Exception("Area of Airport is Less than Mimimum Required Area,Minimum Area Should be 250 Acers");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    goto a;
                }
            }

            Console.WriteLine("Enter Area Alloted for Parking in Acers\n");
            d.AllotedAreaforParking = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Enter Address of Airport\n");
            d.Address = Console.ReadLine();
        c: Console.WriteLine("Enter Minimum No of Flights per day\n");
            d.minflights = Convert.ToInt16(Console.ReadLine());
            if ((d.minflights) < minNoOfFlightsPerDay)
            {
                try
                {
                    throw new Exception("Minimum No Of Flights per day should be more than 5 ");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    goto c;
                }
            }
        x: Console.WriteLine("Enter Maximum No of Flights per day\n");
            d.maxflights = Convert.ToInt16(Console.ReadLine());
            if ((d.maxflights) > MaxNoOfFlightsPerDay)
            {
                try
                {
                    throw new Exception("Maximum No Of Flights per day should be less than 50\n ");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    goto x;
                }
            }
            num = id + i++;
            d.aid = num;
            list1.Add(d);
            Console.WriteLine("New Domestic AirportID added with Airport id:{0}", d.aid);

        }
        public void RemoveAirport()
        {
            Console.WriteLine("Enter Airport ID to be deleted");
            idno = Convert.ToInt32(Console.ReadLine());
            bool temp = false;
            for (int i = 0; i < list1.Count; i++)
            {
                if (list1[i].aid == idno)
                {
                    temp = true;

                    list1.RemoveAt(i);
                    Console.WriteLine("Airport is is Deleted");
                }
            }
            if (temp == false)
            {
                Console.WriteLine("Invalid ID Number");
            }
        }
        public void EditAirportDetails()
        {
            Console.WriteLine("Enter Airport ID to be Edited");
            idno = Convert.ToInt32(Console.ReadLine());
            foreach (DomesticAirport x in list1)
            {
                if (x.aid == idno)
                {
                    Console.WriteLine("Enter the AirportName ");
                    x.AirportName = Console.ReadLine();
                    Console.WriteLine("AirportName changed successfully ");
                }

                else
                {
                    Console.WriteLine("Invalid ID Number");
                }

            }
        }
        public void GetDetailsForNewAirport()
        {
            Console.WriteLine("Minimum Required Length of Air Strip should be:{0}\n ", MinRequiredAirStripLength);
            Console.WriteLine("Minimum No Of Flights per day Shoud be:{0}\n ", minNoOfFlightsPerDay);
            Console.WriteLine("Maximum No Of Flights per day Shoud be:{0}\n ", MaxNoOfFlightsPerDay);
            Console.WriteLine("Distance from should be Less than:{0}\n ", DistanceFromCity);
            Console.WriteLine("Minimum Required Area should be:{0} Acers\n ", MinRequiredAirStripLength);
        }
        public void ShowAirportDetails()
        {
            Console.WriteLine("Enter Airport ID for Details");
            idno = Convert.ToInt32(Console.ReadLine());
            foreach (DomesticAirport x in list1)
            {
                if (x.aid == idno)
                {

                    Console.WriteLine("Airport Name is:" + "\t" + x.AirportName);
                    Console.WriteLine("Airport ID is:" + "\t" + x.aid);
                    Console.WriteLine("City Name is:" + "\t" + x.CityName);
                    Console.WriteLine("Area Alloted for Airport is:" + "\t" + x.AllotedAreaforAirport);
                    Console.WriteLine("Area Alloted for Parking is:" + "\t" + x.AllotedAreaforParking);
                    Console.WriteLine("Address of  Airport is:" + "\t" + x.Address);
                    Console.WriteLine("Minimum No of Flight operations per day is:" + "\t" + x.minflights);
                    Console.WriteLine("Maximum No of Flight operations per day is:" + "\t" + x.maxflights);

                }

                else
                {
                    Console.WriteLine("Invalid ID Number");
                }

            }
        }

    }

    public class InternationalAirport : AirportEssentials
    {
        public int MinRequiredAirStripLength = 2500;
        public int minNoOfFlightsPerDay = 25, minflights;
        public int MaxNoOfFlightsPerDay = 250, maxflights;
        public int DistanceFromCity = 100;
        public int MinNoOfAirBridge = 5,airbridge;
        public int MinRequiredLand = 800;
        public int j = 0;
        public readonly long id = 2017456;
        public long num, aid, idno;

        List<InternationalAirport> list2 = new List<InternationalAirport>();

        public void AddNewAirport()
        {
            InternationalAirport i = new InternationalAirport();


         Console.WriteLine("Enter the Airport Name\n");
            i.AirportName = Console.ReadLine();
            Console.WriteLine("Enter the City Name\n");
            i.CityName = Console.ReadLine();
        b: Console.WriteLine("Enter Area Alloted for Airport in Acers\n");
            i.AllotedAreaforAirport = Convert.ToInt16(Console.ReadLine());
            if ((i.AllotedAreaforAirport) < MinRequiredLand)
            {
                try
                {
                    throw new Exception("Area of Airport is Less than Mimimum Required Area, Please increase the Alloted Area");
                }


                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    goto b;

                }
            }

            Console.WriteLine("Enter Area Alloted for Parking in Acers\n");
            i.AllotedAreaforParking = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Enter Address of Airport\n");
            i.Address = Console.ReadLine();
        d: Console.WriteLine("Enter Minimum No of Flights per day\n");
            i.minflights = Convert.ToInt16(Console.ReadLine());
            if ((i.minflights) < minNoOfFlightsPerDay)
            {
                try
                {
                    throw new Exception("Minimum No Of Flights per day should be more than 25 ");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    goto d;
                }
            }
        p: Console.WriteLine("Enter Maximum No of Flights per day\n");
            i.maxflights = Convert.ToInt16(Console.ReadLine());
            if ((i.maxflights) > MaxNoOfFlightsPerDay)
            {
                try
                {
                    throw new Exception("Maximum No Of Flights per day should be less than 250\n ");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    goto p;
                }

            }
           l: Console.WriteLine("Enter No Of Air Bridges\n");
            i.airbridge = Convert.ToInt16(Console.ReadLine());
            if ((i.airbridge) < MinNoOfAirBridge)
            {
                try
                {
                    throw new Exception("There Should be minimum 5 Air Bridges\n ");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    goto l;
                }

            }
            num = id + j++;
            i.aid = num;
            list2.Add(i);
            Console.WriteLine("New International AirportID added with Airport id:{0}", i.aid);

        }
        public void RemoveAirport()
        {
            Console.WriteLine("Enter Airport ID to be deleted");
            idno = Convert.ToInt32(Console.ReadLine());
            bool temp = false;
            for (int i = 0; i < list2.Count; i++)
            {
                if (list2[i].aid == idno)
                {
                    temp = true;

                    list2.RemoveAt(i);
                    Console.WriteLine("Airport is is Deleted");
                }
            }
            if (temp == false)
            {
                Console.WriteLine("Invalid ID Number");
            }
        }
        public void EditAirportDetails()
        {
            Console.WriteLine("Enter Airport ID to be Edited");
            idno = Convert.ToInt32(Console.ReadLine());
            foreach (InternationalAirport x in list2)
            {
                if (x.aid == idno)
                {
                    Console.WriteLine("Enter the AirportName ");
                    x.AirportName = Console.ReadLine();
                    Console.WriteLine("AirportName changed successfully ");
                }

                else
                {
                    Console.WriteLine("Invalid ID Number");
                }

            }
        }
        public void GetDetailsForNewAirport()
        {
            Console.WriteLine("Minimum Required Length of Air Strip should be:{0}\n ", MinRequiredAirStripLength);
            Console.WriteLine("Minimum No Of Flights per day Shoud be:{0}\n ", minNoOfFlightsPerDay);
            Console.WriteLine("Maximum No Of Flights per day Shoud be:{0}\n ", MaxNoOfFlightsPerDay);
            Console.WriteLine("Distance from should be Less than:{0}\n ", DistanceFromCity);
            Console.WriteLine("Minimum Required Area should be:{0} Acers\n ", MinRequiredAirStripLength);
            Console.WriteLine("Minimum No of Air Bridges should be:{0} \n ", MinNoOfAirBridge);
        }
        public void ShowAirportDetails()
        {
            Console.WriteLine("Enter Airport ID for Details");
            idno = Convert.ToInt32(Console.ReadLine());
            foreach (InternationalAirport x in list2)
            {
                if (x.aid == idno)
                {

                    Console.WriteLine("Airport Name is:" + "\t" + x.AirportName);
                    Console.WriteLine("Airport ID is:" + "\t" + x.aid);
                    Console.WriteLine("City Name is:" + "\t" + x.CityName);
                    Console.WriteLine("Area Alloted for Airport is:" + "\t" + x.AllotedAreaforAirport);
                    Console.WriteLine("Area Alloted for Parking is:" + "\t" + x.AllotedAreaforParking);
                    Console.WriteLine("Address of  Airport is:" + "\t" + x.Address);
                    Console.WriteLine("Minimum No of Flight operations per day is:" + "\t" + x.minflights);
                    Console.WriteLine("Maximum No of Flight operations per day is:" + "\t" + x.maxflights);

                }

                else
                {
                    Console.WriteLine("Invalid ID Number");
                }

            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int x = 1;
            DomesticAirport d = new DomesticAirport();
            InternationalAirport i = new InternationalAirport();
            while (x == 1)
            {
            m:  Console.WriteLine("Select Type of Airport: \n1.Domestic Airport \n2.InterNatinal Airport \n3.Exit");
                int ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        {
                            int y = 1;
                            while (y == 1)
                            {

                                Console.WriteLine("\n");
                                Console.WriteLine("Select the option to be Performed on Domestic Type of Airport:");
                                Console.WriteLine("1.Add New Airport  \n2.Remove Airport \n3.Show Airport Details\n4.Edit Airport Details \n5.Get Details For New Airport \n6.previous menu\n");
                                int ch1 = Convert.ToInt32(Console.ReadLine());

                                switch (ch1)
                                {
                                    case 1:
                                        {

                                            d.AddNewAirport();
                                            break;
                                        }
                                    case 2:
                                        {

                                            d.RemoveAirport();
                                            break;
                                        }
                                    case 3:
                                        {
                                            Console.WriteLine("\n");
                                            d.ShowAirportDetails();
                                            break;
                                        }
                                    case 4:
                                        {

                                            d.EditAirportDetails();
                                            break;
                                        }
                                    case 5:
                                        {

                                            d.GetDetailsForNewAirport();
                                            break;
                                        }
                                    case 6:
                                        {
                                            y = 0;
                                            goto m;

                                            break;
                                        }
                                    default:
                                        {
                                            Console.WriteLine("Enter correct choice");
                                            y = 1;
                                            break;
                                        }
                                }
                            }
                            break;

                        }
                    case 2:
                        {
                            int y = 1;
                            while (y == 1)
                            {
                                Console.WriteLine("\n");
                                Console.WriteLine("Select the option to be Performed on International type of Airports:");
                                Console.WriteLine("1.Add New Airport  \n2.Remove Airport \n3.Show Airport Details4.Edit Airport Details \n5.Get Details For New Airport \n6.Exit");
                                int ch1 = Convert.ToInt32(Console.ReadLine());

                                switch (ch1)
                                {
                                    case 1:
                                        {

                                            i.AddNewAirport();
                                            break;
                                        }
                                    case 2:
                                        {

                                            i.RemoveAirport();
                                            break;
                                        }
                                    case 3:
                                        {
                                            Console.WriteLine("\n");
                                            i.ShowAirportDetails();
                                            break;
                                        }
                                    case 4:
                                        {

                                            i.EditAirportDetails();
                                            break;
                                        }
                                    case 5:
                                        {

                                            i.GetDetailsForNewAirport();
                                            break;
                                        }
                                    case 6:
                                        {
                                            y = -1;
                                            goto m;
                                            break;
                                        }
                                    default:
                                        {

                                            Console.WriteLine("Enter correct choice");
                                            y = 1;
                                            break;
                                        }
                                }
                            }
                            break;
                        }

                    case 3:
                        {
                            x = -1;
                            break;
                        }
                    default:
                        {
                            x = 1;
                            Console.WriteLine("Enter correct choice");
                            break;
                        }
                }
            }
        }
    }
}

