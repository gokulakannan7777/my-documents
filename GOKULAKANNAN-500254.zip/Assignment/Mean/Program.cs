﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace meanmedstd_version2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[6];
            for (int i = 0; i < numbers.Length; i++)
            {

                numbers[i] = Convert.ToInt32(Console.ReadLine());
                //  Console.WriteLine(numbers[i]);
            }
            double mean = numbers.Average();
            Console.WriteLine($"mean is {mean}");


            int numberCount = numbers.Count();
            int halfIndex = numbers.Count() / 2;
            var sortedNumbers = numbers.OrderBy(n => n);
            double median;
            if ((numberCount % 2) == 0)
            {
                median = ((sortedNumbers.ElementAt(halfIndex) +
                    sortedNumbers.ElementAt((halfIndex - 1))) / 2);
            }
            else
            {
                median = sortedNumbers.ElementAt(halfIndex);
            }
            Console.WriteLine($"median is {median}");

            Console.ReadLine();

        }
    }
}
