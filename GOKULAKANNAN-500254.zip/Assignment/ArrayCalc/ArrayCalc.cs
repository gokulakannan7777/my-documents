﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication57
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            float mean, median, std;
            Console.Write("Enter number elements:");
            n = int.Parse(Console.ReadLine());
            if (n < 2)
            {
                Console.WriteLine("elements must not be less than 2.");

            }
            else
            {

                int[] Array = new int[n];


                for (int i = 0; i < n; i++)
                {
                    Console.Write("[{0}]:", i);
                    Array[i] = int.Parse(Console.ReadLine());
                }


                bubblesort(Array, n);



                int sum = 0;
                int b = 0;
                while (b < n)
                {
                    sum = sum + Array[b];
                    b++;
                }

                mean = (float)sum / n;


                if (n % 2 != 0) median = Array[n / 2];
                else median = (Array[(n / 2) - 1] + Array[n / 2]) / (float)2;


                int[,] mode = new int[n, 2];

                for (int i = 0; i < 2; i++)
                    for (int j = 0; j < n; j++) mode[j, i] = 0;
                mode[0, 0] = 1;

                for (int i = 0; i < n; i++)
                    for (int j = 0; j < n - 1; j++)
                        if (Array[i] == Array[j + 1]) { ++mode[i, 0]; mode[i, 1] = Array[i]; }

                int max;
                int k = 0;
                max = mode[0, 0];
                for (int j = 0; j < n; j++)
                    if (max < mode[j, 0]) { max = mode[j, 0]; k = j; }



                float temp = 0.0f;

                for (int j = 0; j < n; j++)
                {
                    temp = temp + (float)Math.Pow(Array[j] - mean, 2);
                }

                std = (float)Math.Sqrt(temp / (n - 1));

                //Show results

                Console.WriteLine("details:");
                Console.WriteLine("-");
                Console.WriteLine("mean:{0}", mean);
                Console.WriteLine("Median:{0}", median);
                if (mode[k, 1] != 0)
                    Console.WriteLine("Mode:{0}", mode[k, 1]);
                else Console.WriteLine("Mode: no mode");
                Console.WriteLine("Standard deviation:{0}", std);


            }
            Console.ReadLine();
        }

        static void bubblesort(int[] a, int n)
        {
            int i, j;
            for (i = 0; i < n; i++)
                for (j = n - 1; j > i; j--)
                    if (a[j] < a[j - 1])
                    {
                        int temp = a[j];
                        a[j] = a[j - 1];
                        a[j - 1] = temp;
                    }
        }
    }
    }