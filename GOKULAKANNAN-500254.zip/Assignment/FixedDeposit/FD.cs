﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FixedDeposit
{
    class FD
    {
        static void Main(string[] args)
        {
            double A, Principal, Rateofint, n, Period, I, P;
            double temp, tem;
            Principal = GetInt("Enter the Principal amount:");
            Rateofint = GetInt("Enter the Rate of Interest:");
            Period = GetInt("Enter the periods(in years):");
            n = GetInt("Enter the Range:");
            temp = (1 + Rateofint / n);
            tem = n * Period;
            P = Math.Pow(temp,tem);
            A = Principal * P;

            Console.WriteLine("\nFixed deposit: "+ A);
            I = A - Principal;
            Console.WriteLine("\nInterest Earned Amount:"+ I);
            Console.ReadKey();
        }
        private static double GetInt(string v)
        {
            double val;
            while (true)
            {
                Console.WriteLine(v);
                if (double.TryParse(Console.ReadLine(), out val))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Error! re-try");
                }
            }
            return val;
        }
    }
}


