﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Primenum
{
    class Primenum
    {
        static void Main(string[] args)
        {
           Primenum mpc = new Primenum();
            Console.WriteLine("Enter the Number:");
            int number;
            int.TryParse(Console.ReadLine(),out number);
            bool x = mpc.isPrimeNumber(number);
            Console.WriteLine("Result:" + x);
            Console.ReadKey();
        }

        public bool isPrimeNumber(int number)
        {

            for (int i = 2; i <= number - 1; i++)
            {
                if (number % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
