﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{
    class BankDet
    {
        private static int amount=0,withdraw;
        private static string Name;
        static void Main(string[] args)
        {
            int amount = 0, deposit, withdraw;
            int choice,  x = 0;
            //Console.WriteLine(" To assign initial values\n");
            Initial();
            Console.WriteLine("1. To deposit an amount\n");
            Console.WriteLine("2. To withdraw an amount\n");
            Console.WriteLine("3. To diplay the name and balance\n");
            Console.WriteLine("Enter your choice: ");
            choice = int.Parse(Console.ReadLine());
            switch(choice)
            {
                case 1:
                    Deposit();
                    break;
                case 2:
                    Withdraw();
                    break;
                case 4:
                    Details();
                    break;
            }
            Console.ReadKey();
        }

        private static void Initial()
        {
            Console.WriteLine("Enter the Name:\n");
            Name = Console.ReadLine();
            Console.WriteLine("Enter the Account Number:\n");
            int accnum=int.Parse(Console.ReadLine());
            Console.WriteLine("Saving or Cuurent\n");
            string acctype = Console.ReadLine();
        }

        private static void Details()
        {
            Console.WriteLine("Name of the account hoder:");
            Console.WriteLine($"Balance of :{Name }is{amount}");
        }

        private static void Withdraw()
        {
            Console.WriteLine("\n ENTER THE AMOUNT TO WITHDRAW: ");
            withdraw = int.Parse(Console.ReadLine());
            if (withdraw % 100 != 0)
            {
                Console.WriteLine("\n PLEASE ENTER THE AMOUNT IN MULTIPLES OF 100");
            }
            else if (withdraw > (amount - 500))
            {
                Console.WriteLine("\n INSUFFICENT BALANCE");
            }
            else
            {
                amount = amount - withdraw;
                Console.WriteLine("\n\n PLEASE COLLECT CASH");
                Console.WriteLine("\n YOUR CURRENT BALANCE IS {0}", amount);
            }
        }

        private static void Deposit()
        {
            Console.WriteLine("\n ENTER THE AMOUNT TO DEPOSIT");
            int deposit = int.Parse(Console.ReadLine());
            amount = + deposit;
            Console.WriteLine("YOUR BALANCE IS {0}", amount);
        }
    }
}
