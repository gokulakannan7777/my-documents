﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sorting
{
    class Program
    {
        public static int[] arr;
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the totel numbers");
            int num = int.Parse(Console.ReadLine());
            arr = new int[num];
            string[] menuOption = { "1. Ascending Order", "2. Descending Order" };
            foreach (var item in menuOption)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Enter your Choice");
            int choice = int.Parse(Console.ReadLine());

            Stopwatch stop = new Stopwatch();
            Console.WriteLine("Enter numbers for array");
            for (int i = 0; i < num; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
            }

            switch (choice)
            {
                case 1:
                    stop.Start();
                    normalSort(arr);
                    stop.Stop();
                    TimeSpan t1 = stop.Elapsed;
                    Console.WriteLine($" The total time elapsed in Normal Sort is {t1}");
                    stop.Start();
                    bubbleSort(arr);
                    stop.Stop();
                    TimeSpan t2 = stop.Elapsed;
                    Console.WriteLine($" The total time elapsed in Bubble Sort is {t2}");
                    stop.Start();
                    insertionSort(arr);
                    stop.Stop();
                    TimeSpan t3 = stop.Elapsed;
                    Console.WriteLine($" The total time elapsed in Insertion Sort is {t3}");
                    stop.Start();
                    selectionSort(arr);
                    stop.Stop();
                    TimeSpan t4 = stop.Elapsed;
                    Console.WriteLine($" The total time elapsed in Selection Sort is {t4}");
                    break;
                case 2:
                    stop.Start();
                    normalsortd(arr);
                    stop.Stop();
                    TimeSpan t5 = stop.Elapsed;
                    Console.WriteLine($" The total time elapsed in Normal Sort is {t5}");
                    stop.Start();
                    bubbleSortd(arr);
                    stop.Stop();
                    TimeSpan t6 = stop.Elapsed;
                    Console.WriteLine($" The total time elapsed in Selection Sort is {t6}");
                    stop.Start();
                    insertionSortd(arr);
                    stop.Stop();
                    TimeSpan t7 = stop.Elapsed;
                    Console.WriteLine($" The total time elapsed in Selection Sort is {t7}");
                    stop.Start();
                    selectionSortd(arr);
                    stop.Stop();
                    TimeSpan t8 = stop.Elapsed;
                    Console.WriteLine($" The total time elapsed in Selection Sort is {t8}");
                    break;
                default:
                    Console.WriteLine("Invalid Value");
                    break;
            }
            //time taken
            //number of operations done
            Console.ReadLine();
        }

        private static void insertionSort(int[] arr)
        {
            int n = arr.Length;
            for (int j = 1; j < n; j++)
            {
                int key = arr[j];
                int i = j - 1;
                while ((i > -1) && (arr[i] > key))
                {
                    arr[i + 1] = arr[i];
                    i--;
                }
                arr[i + 1] = key;
            }

            Console.WriteLine("Array after insertion sort :");
            for (int i = 0; i < arr.Length; i++)
                Console.Write(" " + arr[i]);
            Console.WriteLine();
        }

        private static void insertionSortd(int[] arr)
        {
            for (int i = 1; i > arr.Length; i++)
            {
                int item = arr[i];
                int ins = 0;
                for (int j = i - 1; j >= 0 && ins != 1;)
                {
                    if (item < arr[j])
                    {
                        arr[j + 1] = arr[j];
                        j--;
                        arr[j + 1] = item;
                    }
                    else ins = 1;
                }
            }

            Console.WriteLine("Array after Insertion sort Using Descending order:");

            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(" " + arr[i]);
            }
            Console.WriteLine();
        }

        private static void bubbleSort(int[] arr)
        {
            for (int i = arr.Length - 1; i > 0; i--)
            {
                for (int j = 0; j <= i - 1; j++)
                {
                    if (arr[j] > arr[j + 1])
                    {
                        int temp = arr[j];

                        arr[j] = arr[j + 1];
                        arr[j + 1] = temp;
                    }
                }
            }
            Console.WriteLine("Array after Bubble sort:");

            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(" " + arr[i]);

            }
            Console.WriteLine();
        }
        private static void bubbleSortd(int[] arr)
        {
            for (int i = arr.Length - 1; i > 0; i--)
            {
                for (int j = 0; j <= i - 1; j++)
                {
                    if (arr[j] < arr[j + 1])
                    {
                        int temp = arr[j];

                        arr[j] = arr[j + 1];
                        arr[j + 1] = temp;
                    }
                }
            }
            Console.WriteLine("Array after Bubble sort using descending order:");

            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(" " + arr[i]);

            }
            Console.WriteLine();
        }
        private static void selectionSort(int[] arr)
        {

            int tmp, min_key;

            for (int j = 0; j < arr.Length - 1; j++)
            {
                min_key = j;

                for (int k = j + 1; k < arr.Length; k++)
                {
                    if (arr[k] < arr[min_key])
                    {
                        min_key = k;
                    }
                }

                tmp = arr[min_key];
                arr[min_key] = arr[j];
                arr[j] = tmp;
            }

            Console.WriteLine("Array After Selection Sort: ");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(" " + arr[i]);
            }
            Console.WriteLine();
        }

        private static void selectionSortd(int[] arr)
        {
            for (int i = 0; i < arr.Length; ++i)
            {
                for (int j = i + 1; j < arr.Length; ++j)
                {
                    if (arr[i] < arr[j])
                    {
                        int temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
            }
            Console.WriteLine("Selection Sorting in descending order");
            for (int i = 0; i < arr.Length; ++i)
            {
                Console.Write(" " + arr[i]);
            }
            Console.WriteLine();
        }
        private static void normalSort(int[] arr)
        {

            Array.Sort(arr);
            Console.WriteLine("After Normal Sort:");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(" " + arr[i]);
            }
            Console.WriteLine();
        }
        private static void normalsortd(int[] arr)
        {
            Array.Sort(arr);
            Array.Reverse(arr);
            Console.WriteLine("After normal sort in descending order");
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                Console.Write(" " + arr[i]);
            }
            Console.WriteLine();
        }

    }
}

